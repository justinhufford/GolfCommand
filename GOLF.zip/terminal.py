from contextlib import contextmanager
import math
import os
import sys
import textwrap
import time

from items import plain_text


WIDTH = 36
MARGIN = "  "
LINE_WIDTH = len(MARGIN) + WIDTH
METER_HALF_CYCLE = 1.5
ACCENT = "\033[38;5;42m"
WHITE = "\033[37m"
RESET = "\033[0m"


def enable_color():
    if not sys.stdout.isatty() or "NO_COLOR" in os.environ:
        return False
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.windll.kernel32
        kernel.GetStdHandle.restype = wintypes.HANDLE
        handle = kernel.GetStdHandle(-11)
        mode = wintypes.DWORD()
        if not kernel.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        return bool(kernel.SetConsoleMode(handle, mode.value | 4))
    return True


@contextmanager
def keyboard():
    if os.name == "nt":
        import msvcrt

        def read_key(timeout):
            deadline = time.monotonic() + timeout
            while True:
                if msvcrt.kbhit():
                    key = msvcrt.getwch()
                    if key in ("\x00", "\xe0"):
                        msvcrt.getwch()
                        return ""
                    return key
                if time.monotonic() >= deadline:
                    return ""
                time.sleep(0.01)

        yield read_key
    else:
        import select
        import termios
        import tty
        handle = sys.stdin.fileno()
        original = termios.tcgetattr(handle)
        try:
            tty.setcbreak(handle)

            def read_key(timeout):
                if select.select([sys.stdin], [], [], timeout)[0]:
                    return os.read(handle, 1).decode("utf-8", errors="ignore")
                return ""

            yield read_key
        finally:
            termios.tcsetattr(handle, termios.TCSADRAIN, original)


def meter_power(elapsed):
    phase = (elapsed / METER_HALF_CYCLE) % 2
    return phase if phase <= 1 else 2 - phase


def meter_line(power, rising=True, locked=False, unicode=True):
    marker_count = WIDTH
    filled = int(power * marker_count + 0.5)
    full, empty = ("▌", "·") if unicode else ("|", ".")
    return "".join(full if index < filled else empty
                   for index in range(marker_count))


class Terminal:
    def __init__(self, fast=False, manual_power=False):
        self.color = enable_color()
        self.interactive = sys.stdin.isatty() and sys.stdout.isatty()
        self.delay = 0 if fast or not self.interactive else 0.035
        self.manual_power = manual_power

    def ink(self, text, accent=False):
        if not self.color:
            return text
        return (ACCENT if accent else WHITE) + text + WHITE

    def pause(self, seconds):
        if self.delay and seconds > 0:
            time.sleep(seconds)

    @staticmethod
    def display_text(text, fallback=None):
        text = str(text)
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
        try:
            text.encode(encoding)
            return text
        except (LookupError, UnicodeEncodeError):
            return plain_text(text) if fallback is None else fallback

    def _print(self, parts, delay=None):
        """Lay out plain text before applying ink, so color never affects width."""
        length = sum(len(text) for text, _ in parts)
        line = "".join(self.ink(text, accent) for text, accent in parts)
        print(MARGIN + line if length else "", flush=True)
        if delay is None:
            delay = min(0.085, self.delay + length * 0.0012) if length else 0.10
        self.pause(delay)

    def write(self, text="", accent=False, delay=None):
        for paragraph in str(text).split("\n"):
            lines = textwrap.wrap(plain_text(paragraph), width=WIDTH) or [""]
            for line in lines:
                self._print([(line.rstrip(), accent)], delay)

    def center(self, text, accent=False, delay=None):
        for line in textwrap.wrap(plain_text(text), width=WIDTH) or [""]:
            self._print([(line.center(WIDTH).rstrip(), accent)], delay)

    def visual(self, text, fallback=None, *, center=False, delay=None):
        line = self.display_text(text, fallback)[:WIDTH]
        if center:
            line = line.center(WIDTH).rstrip()
        self._print([(line, False)], delay)

    def art(self, text, accent=False, fallback=None):
        lines = str(text).strip("\n").splitlines()
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
        try:
            str(text).encode(encoding)
        except (LookupError, UnicodeEncodeError):
            if fallback is not None:
                lines = fallback.strip("\n").splitlines()
        inset = " " * max(0, (WIDTH - max(map(len, lines), default=0)) // 2)
        for line in lines:
            line = line[:WIDTH].rstrip()
            try:
                line.encode(encoding)
            except (LookupError, UnicodeEncodeError):
                line = "".join(character if character.isascii() else "+" for character in line)
            self._print([(inset + line, accent)], 0.055)

    def rule(self):
        self.write("-" * WIDTH, delay=0.035)

    def title(self, text):
        self.write()
        self.center(text.upper(), delay=0.08)
        self.rule()
        self.pause(0.14)

    def sound(self, text, accent=False):
        sound = plain_text(text).strip(" \"'*_`").upper()[:WIDTH - 6]
        self.write(delay=0)
        self.center(sound, accent=accent, delay=0)
        self.write(delay=0)
        self.pause(0.55)

    def row(self, label, value, accent=False, *, label_accent=False, prefix=""):
        label, value = plain_text(label), plain_text(value)
        prefix = plain_text(prefix)
        room = WIDTH - len(prefix) - (len(value) + 2 if value else 0)
        if room < 12 and value:
            self.row(label, "", label_accent=label_accent, prefix=prefix)
            for line in textwrap.wrap(value, width=WIDTH) or [""]:
                self._print([(line.rjust(WIDTH), accent)], 0.045)
            return
        lines = textwrap.wrap(label, width=max(1, room)) or [""]
        for index, line in enumerate(lines):
            lead = prefix if index == 0 else " " * len(prefix)
            parts = [(lead, False), (line, label_accent)]
            if index == len(lines) - 1 and value:
                parts.append((" " * (WIDTH - len(lead) - len(line) - len(value)), False))
                parts.append((value, accent))
            self._print(parts, 0.045)

    def replace_line(self, text, accent=False, prefix="", *, fallback=None):
        text = (plain_text(text) if fallback is None else self.display_text(text, fallback))
        text = text[:WIDTH - len(prefix)]
        line = self.ink(prefix) + self.ink(text, accent)
        padding = " " * (WIDTH - len(prefix) - len(text))
        sys.stdout.write("\r" + MARGIN + line + self.ink(padding))
        sys.stdout.flush()

    def ask(self, label=None, swing_prompt=False):
        if label:
            self.write(label)
        if not self.interactive:
            answer = input(MARGIN + self.ink("> ")).strip()
            print()
            return answer
        text = ""
        self.replace_line("", prefix="> ")
        with keyboard() as read_key:
            while True:
                key = read_key(0.05)
                if key in ("\r", "\n"):
                    if not (swing_prompt and not self.manual_power and text.strip().lower() in ("", "swing")):
                        print()
                    return text.strip()
                if key in ("\x03", "\x04", "\x1a"):
                    raise KeyboardInterrupt
                if key in ("\x08", "\x7f"):
                    text = text[:-1]
                elif key and key.isprintable() and len(text) < 2000:
                    text += key
                if key:
                    visible = plain_text(text)
                    if len(visible) > WIDTH - 2:
                        visible = "<" + visible[-(WIDTH - 3):]
                    self.replace_line(visible, accent=True, prefix="> ")

    def swing_meter(self):
        if self.manual_power or not self.interactive:
            while True:
                value = self.ask("Power 0-100 / cancel to go back:")
                if value.lower() == "cancel":
                    self.write("Swing cancelled. No stroke used.")
                    return None
                try:
                    power = float(value) / 100
                    if math.isfinite(power) and 0 <= power <= 1:
                        self.write()
                        self.visual(meter_line(power, locked=True),
                                    meter_line(power, locked=True, unicode=False), delay=0.08)
                        self.write()
                        return power
                except ValueError:
                    pass
                self.write("Try a number from 0 to 100, e.g. 25.")
        self.replace_line("")
        print()
        print()
        start = time.monotonic()
        with keyboard() as read_key:
            while True:
                elapsed = time.monotonic() - start
                power = meter_power(elapsed)
                rising = (elapsed / METER_HALF_CYCLE) % 2 <= 1
                self.replace_line(meter_line(power, rising=rising),
                                  fallback=meter_line(power, rising=rising, unicode=False))
                key = read_key(0.02)
                if key in ("\r", "\n"):
                    power = meter_power(time.monotonic() - start)
                    self.replace_line(meter_line(power, locked=True),
                                      fallback=meter_line(power, locked=True, unicode=False))
                    print()
                    print()
                    return power
                if key == "\x1b":
                    self.replace_line("Swing cancelled. No stroke used.")
                    print()
                    print()
                    return None
                if key in ("\x03", "\x04", "\x1a"):
                    raise KeyboardInterrupt

    def close(self):
        if self.color:
            sys.stdout.write(RESET)
            sys.stdout.flush()
