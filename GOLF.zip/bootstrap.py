from pathlib import Path
import shutil
import subprocess
import sys
import venv


ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 10):
        print("GOLF needs Python 3.10 or newer.")
        return 1
    environment = ROOT / ".venv"
    python = environment / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
    if not python.exists():
        print("Setting up your golf bag...", flush=True)
        venv.EnvBuilder(with_pip=True).create(environment)
    requirements = ROOT / "requirements.txt"
    installed = environment / "golf-requirements.txt"
    demo = "--demo" in sys.argv[1:]
    if not demo:
        check = subprocess.run([str(python), "-c", "import openai, anthropic"], capture_output=True)
        changed = not installed.exists() or installed.read_bytes() != requirements.read_bytes()
        if check.returncode or changed:
            print("Installing the two API clients...", flush=True)
            with (environment / "setup.log").open("w", encoding="utf-8") as log:
                pip = subprocess.run([str(python), "-m", "pip", "--version"], capture_output=True)
                if pip.returncode:
                    repair = subprocess.run([str(python), "-m", "ensurepip"], stdout=log,
                                            stderr=subprocess.STDOUT)
                    if repair.returncode:
                        print("Python package setup failed.")
                        print("Details: .venv/setup.log")
                        return repair.returncode
                result = subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check",
                                         "-r", str(requirements)], stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                print("Install failed. Check internet.")
                print("Details: .venv/setup.log")
                return result.returncode
            shutil.copyfile(requirements, installed)
        env_file = ROOT / ".env"
        if not env_file.exists():
            shutil.copyfile(ROOT / ".env.example", env_file)
            print("Created .env for your API key.", flush=True)
            print("You can also choose demo to play.", flush=True)
    return subprocess.call([str(python), str(ROOT / "GOLF.py"), *sys.argv[1:]], cwd=ROOT)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, subprocess.SubprocessError):
        print("Setup failed. Check Python and")
        print("folder write access, then retry.")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nSetup cancelled.")
        sys.exit(130)
