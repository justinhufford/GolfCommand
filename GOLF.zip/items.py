from dataclasses import asdict, dataclass
from decimal import Decimal, ROUND_HALF_UP, localcontext
import math
import unicodedata


STAT_LIMITS = {
    "mass_kg": (1e-40, 1e50, "Mass in kilograms; keep subatomic and astronomical scale."),
    "length_m": (0, 1e30, "Longest dimension in meters; pointlike objects may be zero."),
    "area_m2": (0, 1e60, "Frontal area in square meters; pointlike objects may be zero."),
    "loft_degrees": (0, 90, "Usual striking face tilt in degrees; 0 for a flat impact face."),
    "grip": (0, 1, "Ease of holding: 0 for loose gas, 1 for a good handle."),
    "rigidity": (0, 1, "Shape-holding stiffness: 0 flexible, 1 rigid."),
    "restitution": (0, 1, "Bounciness: 0 for inelastic, 1 for perfectly elastic."),
    "drag_coefficient": (0, 3, "Air drag coefficient."),
    "rolling_resistance": (0, 1, "Resistance on grass: 0 unstoppable, 0.08 round, 0.6 lumpy."),
    "hardness": (0, 1, "Relative surface hardness: 0 intangible, egg 0.03, steel 0.8, diamond 1."),
    "durability_j": (1e-40, 1e60, "Absorbed joules to destroy this whole object."),
}

INFINITE_STATS = {"mass_kg", "length_m", "area_m2", "durability_j"}


def plain_text(value):
    text = unicodedata.normalize("NFKD", str(value))
    return "".join(c if 32 <= ord(c) < 127 else " " for c in text)


def number(value, low, high, name, *, allow_infinity=False):
    if allow_infinity and value == "Infinity":
        return math.inf
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Invalid {name}.")
    if allow_infinity and value == math.inf:
        return math.inf
    if allow_infinity and value > high:
        return math.inf
    if not low <= value <= high or not math.isfinite(value):
        raise ValueError(f"Out of range: {name}.")
    return float(value)


def dollars_to_cents(value):
    number(value, 0.01, 1e60, "price")
    with localcontext() as context:
        context.prec = 80
        return int((Decimal(str(value)) * 100).to_integral_value(rounding=ROUND_HALF_UP))


def money(cents):
    if abs(cents) >= 100_000_000_000:
        return f"${cents / 100:.2e}"
    sign = "-" if cents < 0 else ""
    whole, fraction = divmod(abs(cents), 100)
    return f"{sign}${whole:,}.{fraction:02d}"


@dataclass
class Item:
    id: str
    name: str
    description: str
    material: str
    price_cents: int
    mass_kg: float
    length_m: float
    area_m2: float
    loft_degrees: float
    grip: float
    rigidity: float
    restitution: float
    drag_coefficient: float
    rolling_resistance: float
    hardness: float
    durability_j: float
    condition: float = 100.0
    ai_generated: bool = False

    @classmethod
    def from_generated(cls, data, item_id, *, ai_generated=False):
        fields = {"name", "description", "material", "price_usd", *STAT_LIMITS}
        if not isinstance(data, dict) or set(data) != fields:
            raise ValueError("Incomplete item details.")
        strings = {}
        for key, limit in (("name", 80), ("description", 240), ("material", 80)):
            value = data[key]
            if not isinstance(value, str) or not 1 <= len(value) <= limit:
                raise ValueError(f"Invalid item {key}.")
            strings[key] = " ".join(plain_text(value).split())
            if not strings[key]:
                raise ValueError(f"Empty item {key}.")
        stats = {key: number(data[key], low, high, key,
                             allow_infinity=key in INFINITE_STATS)
                 for key, (low, high, _) in STAT_LIMITS.items()}
        return cls(id=item_id, **strings, price_cents=dollars_to_cents(data["price_usd"]),
                   **stats, ai_generated=ai_generated)

    @property
    def usable(self):
        return self.condition > 0

    @property
    def resale_cents(self):
        # Basis points keep even astronomical prices in integer arithmetic.
        condition_points = int(max(0, min(100, self.condition)) * 100)
        return self.price_cents * 60 * condition_points // 1_000_000

    def damage(self, amount):
        self.condition = max(0.0, self.condition - max(0.0, amount))

    def details(self):
        return asdict(self) | {"resale_cents": self.resale_cents}
