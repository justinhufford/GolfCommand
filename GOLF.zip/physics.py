from dataclasses import dataclass
import math

from items import Item, number


SWING_ENERGY_J = 280.0
MAX_SWING_SPEED = 55.0
HAND_SPEED = 10.0
LIFT_MASS_KG = 12.0
AIR_DENSITY = 1.225
GRAVITY = 9.81
METERS_PER_YARD = 0.9144
CUP_RADIUS_M = 0.6
MAX_STROKES = 12


@dataclass
class Shot:
    distance_m: float
    club_speed: float
    ball_speed: float
    ball_damage: float
    club_damage: float
    note: str
    ball_broken: bool = False


def stopping_distance(ball, speed):
    friction = ball.rolling_resistance * GRAVITY
    drag = 0.5 * AIR_DENSITY * ball.drag_coefficient * ball.area_m2 / ball.mass_kg
    if speed == 0:
        return 0.0
    if friction == 0:
        return math.inf
    if drag == 0:
        return speed * speed / (2 * friction)
    return math.log1p(drag * speed * speed / friction) / (2 * drag)


def calculate_shot(ball: Item, club: Item, power: float):
    number(power, 0, 1, "power")
    if ball.id == club.id:
        raise ValueError("Choose two different items.")
    if not ball.usable or not club.usable:
        raise ValueError("Replace broken equipment first.")
    if power == 0:
        return Shot(0, 0, 0, 0, 0, "A practice-sized whiff.")

    reach = 0.25 + 0.75 * min(club.length_m / 1.2, 1)
    lift = 1 / (1 + (club.mass_kg / LIFT_MASS_KG) ** 2)
    energy = SWING_ENERGY_J * power ** 2 * club.grip * reach * lift
    energy *= club.condition / 100
    lever = min(club.length_m / 1.1, 1)
    speed_limit = HAND_SPEED + (MAX_SWING_SPEED - HAND_SPEED) * lever
    club_speed = min(speed_limit, math.sqrt(2 * energy / club.mass_kg))
    rigidity = ball.rigidity * club.rigidity
    bounce = math.sqrt(ball.restitution * club.restitution) * rigidity
    bounce *= math.sqrt(ball.condition * club.condition) / 100
    mass_share = club.mass_kg / (club.mass_kg + ball.mass_kg)
    ball_speed = (1 + bounce) * mass_share * club_speed * rigidity
    forward_contact = math.cos(math.radians(club.loft_degrees)) ** 2
    ball_speed *= forward_contact

    reduced_mass = mass_share * ball.mass_kg
    impact_energy = 0.5 * reduced_mass * club_speed ** 2 * forward_contact
    absorbed = impact_energy * (1 - bounce ** 2 * rigidity ** 2)
    absorbed += impact_energy * 0.002
    combined_hardness = ball.hardness + club.hardness
    ball_share = club.hardness / combined_hardness if combined_hardness else 0.5
    ball_damage = 100 * absorbed * ball_share / ball.durability_j
    club_damage = 100 * absorbed * (1 - ball_share) / club.durability_j

    if ball_damage >= ball.condition:
        return Shot(0, club_speed, 0, ball.condition, min(club.condition, club_damage),
                    "The ball breaks on impact.", ball_broken=True)
    if club_damage >= club.condition:
        ball_speed *= math.sqrt(club.condition / club_damage)
        note = "The club breaks on impact."
    else:
        note = "A clean connection."
    distance = stopping_distance(ball, ball_speed)
    if distance < 0.01 and club_damage < club.condition:
        note = "It barely moves."
    return Shot(distance, club_speed, ball_speed, min(ball.condition, ball_damage),
                min(club.condition, club_damage), note)


def swing(ball, club, power):
    shot = calculate_shot(ball, club, power)
    ball.damage(shot.ball_damage)
    club.damage(shot.club_damage)
    return shot


@dataclass
class Hole:
    length_m: float
    par: int
    strokes: int = 0
    position_m: float = 0.0
    complete: bool = False

    @property
    def remaining_m(self):
        return abs(self.length_m - self.position_m)

    def hit(self, shot):
        self.strokes += 1
        direction = 1 if self.position_m <= self.length_m else -1
        self.position_m += direction * shot.distance_m
        if self.remaining_m <= CUP_RADIUS_M and shot.distance_m > 0 and not shot.ball_broken:
            self.complete = True
            self.position_m = self.length_m

    @property
    def prize_cents(self):
        if not self.complete:
            return 0
        if self.strokes == 1:
            return 30_000
        score = self.strokes - self.par
        return max(2_500, 10_000 - score * 2_500)

    @property
    def score_name(self):
        if self.strokes == 1:
            return "Hole in one!"
        return {-3: "Albatross", -2: "Eagle", -1: "Birdie", 0: "Par",
                1: "Bogey", 2: "Double bogey"}.get(self.strokes - self.par, "Hole complete")
