import json
import random

from settings import ROOT


def load_catalog():
    return json.loads((ROOT / "demo_items.json").read_text(encoding="utf-8"))


class DemoShopkeeper:
    provider = "demo"
    model = "Offline sample catalog"
    sounds = ["THWACK!", "BONK!", "PING!", "CLONK!", "SMACK!", "PLOP!", "TINK!"]

    def request(self, text, shop):
        catalog = load_catalog()
        wanted = text.casefold().strip()
        if wanted == "starter":
            selected = catalog[:2]
        elif wanted == "lunch":
            selected = catalog[8:11]
        else:
            selected = [item for item in catalog if wanted in item["name"].casefold()]
        if not selected or (wanted not in ("starter", "lunch") and len(selected) != 1):
            raise ValueError("Demo: enter one catalog name, starter, or lunch.")
        return {"message": "Coming right up.", "intent": "edit", "actions": [
            {"kind": "add", "item_id": "", "item": item} for item in selected
        ]}

    def sound_effect(self, club_name, ball_name):
        return random.choice(self.sounds)
