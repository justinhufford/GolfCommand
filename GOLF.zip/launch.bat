@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "GOLF_EXIT_CODE=1"
cd /d "%~dp0"
title GOLF
if exist ".venv\Scripts\python.exe" goto existing
where py >nul 2>nul
if not errorlevel 1 goto launcher
where python >nul 2>nul
if not errorlevel 1 goto python
echo Install Python 3.10 or newer.
echo Enable Add Python to PATH.
goto finish
:existing
".venv\Scripts\python.exe" bootstrap.py %*
set "GOLF_EXIT_CODE=%errorlevel%"
goto finish
:launcher
py -3 bootstrap.py %*
set "GOLF_EXIT_CODE=%errorlevel%"
goto finish
:python
python bootstrap.py %*
set "GOLF_EXIT_CODE=%errorlevel%"
:finish
echo.
echo Press any key to close.
pause >nul
exit /b %GOLF_EXIT_CODE%
