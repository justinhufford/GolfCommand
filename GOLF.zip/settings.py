from pathlib import Path
import os


ROOT = Path(__file__).resolve().parent
DEFAULT_MODELS = {"openai": "gpt-4.1-mini", "anthropic": "claude-haiku-4-5-20251001"}


def load_env(path=None):
    path = Path(path) if path is not None else ROOT / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        key, separator, value = line.partition("=")
        if not separator:
            continue
        key, value = key.strip(), value.strip()
        if value[:1] in ("'", '"') and value[-1:] == value[:1]:
            value = value[1:-1]
        else:
            value = value.split(" #", 1)[0].rstrip()
        if key:
            os.environ.setdefault(key, value)


def has_key(provider):
    value = os.environ.get(f"{provider.upper()}_API_KEY", "").strip()
    return bool(value) and not any(word in value.lower() for word in
                                  ("your-key", "your_key", "paste", "replace", "example"))


def model_for(provider):
    return os.environ.get(f"{provider.upper()}_MODEL", "").strip() or DEFAULT_MODELS[provider]
