"""An opt-in live model check. Running this file makes paid API requests."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path

from ai_shop import AIShopkeeper, ShopError
from physics import METERS_PER_YARD, calculate_shot
from settings import load_env
from shop import Shop
from terminal import Terminal


LUNCH_REQUEST = ("yeaaah can I get a double cheeseburger, plain, a large dr pepper, "
                 "and fries? Actually, make that a small")
EQUIPMENT_REQUEST = (
    "One of each, in this exact order: a regulation golf ball, a standard driver, "
    "a 7-iron, a putter, a sand wedge, a raw chicken egg, an incandescent "
    "lightbulb, a 5kg sledgehammer, a 10g industrial diamond, and the actual Sun. "
    "Give me a quote only."
)


def check(condition, message):
    if not condition:
        raise ValueError(message)


def run_checks(keeper, ui, report):
    def request(text, shop):
        ui.write("Requesting a quote...", accent=True)
        response = keeper.request(text, shop)
        report["responses"].append({"request": text, "response": response, "usage": keeper.last_usage.copy()})
        shop.apply(response)
        for thing in shop.cart:
            ui.write(f"{thing.id} {thing.name}")
        return response

    lunch = Shop()
    request(LUNCH_REQUEST, lunch)
    names = [thing.name.lower().replace(".", "") for thing in lunch.cart]
    check(len(names) == 3, "Lunch should contain three items.")
    check(any("double" in name and "cheeseburger" in name and "plain" in name for name in names),
          "Missing plain double cheeseburger.")
    check(any("small" in name and "pepper" in name for name in names), "The drink should be small.")
    check(any("fries" in name for name in names), "Missing fries.")
    ui.write("PASS: the lunch stress test.", accent=True)
    before = {thing.id: asdict(thing) for thing in lunch.cart if "fries" not in thing.name.lower()}
    request("Actually, remove the fries.", lunch)
    check({thing.id: asdict(thing) for thing in lunch.cart} == before, "Removal changed other items.")
    ui.write("PASS: conversational removal.", accent=True)
    lunch.checkout()
    request("I'd like to sell back the drink.", lunch)
    check(len(lunch.selling) == 1, "Expected one drink trade-in.")
    check("pepper" in lunch.find(lunch.inventory, lunch.selling[0]).name.lower(), "Wrong item on trade-in.")
    ui.write("PASS: conversational trade-in.", accent=True)

    equipment = Shop()
    request(EQUIPMENT_REQUEST, equipment)
    check(len(equipment.cart) == 10, "Expected ten equipment samples.")
    ball, driver, iron, putter, wedge, egg, bulb, hammer, diamond, sun = equipment.cart
    for thing, words in zip(equipment.cart, (("golf", "ball"), ("driver",), ("iron",), ("putter",),
                                             ("wedge",), ("egg",), ("bulb",), ("hammer",), ("diamond",), ("sun",))):
        check(all(word in thing.name.lower() for word in words), "Equipment order or identity changed.")
    check(0.04 < ball.mass_kg < 0.05, "Regulation ball mass is implausible.")
    check(1e30 < sun.mass_kg < 3e30, "The Sun's mass is not solar scale.")
    check(sun.price_cents > equipment.wallet, "The Sun should be unaffordable.")
    for target, club in ((ball, driver), (ball, iron), (ball, putter), (ball, wedge),
                         (egg, hammer), (bulb, hammer), (diamond, hammer),
                         (ball, egg), (sun, driver), (ball, sun)):
        ui.rule()
        ui.write(f"{club.name} -> {target.name}")
        for power in (0.01, 0.1, 0.5, 1):
            shot = calculate_shot(target, club, power)
            report["shots"].append({"ball": target.name, "club": club.name,
                                    "power": power, **asdict(shot)})
            ui.row(f"{power:.0%} power", f"{shot.distance_m / METERS_PER_YARD:.2f} yd")
    driver_distance = calculate_shot(ball, driver, 1).distance_m / METERS_PER_YARD
    check(150 < driver_distance < 450, "Driver distance needs calibration.")
    check(calculate_shot(egg, hammer, 1).ball_broken, "The egg should break under the hammer.")
    check(calculate_shot(bulb, hammer, 1).ball_broken, "The bulb should break under the hammer.")
    check(calculate_shot(diamond, hammer, 1).ball_damage < 25, "Diamond durability needs calibration.")
    check(calculate_shot(ball, putter, 0.01).distance_m < 1, "Putter needs finer low-power control.")
    ui.write("PASS: generated physics baselines.", accent=True)


def main():
    parser = argparse.ArgumentParser(description="Four paid API calls to check shop intent and generated physics.")
    parser.add_argument("--provider", choices=["openai", "anthropic"], required=True)
    parser.add_argument("--output", type=Path, default=Path("api-test-results.json"))
    args = parser.parse_args()
    load_env()
    ui = Terminal(fast=True)
    report = {"provider": args.provider, "responses": [], "shots": [], "passed": False}
    try:
        keeper = AIShopkeeper(args.provider)
        report["model"] = keeper.model
        ui.title("Live API check")
        ui.write(f"Provider: {keeper.provider}")
        ui.write(f"Model: {keeper.model}")
        run_checks(keeper, ui, report)
        report["passed"] = True
        ui.write("All live checks passed.", accent=True)
        return 0
    except (ValueError, ShopError) as error:
        report["error"] = str(error)
        ui.write(str(error))
        return 1
    finally:
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        ui.write("Results written to:")
        ui.write(str(args.output))
        ui.close()


if __name__ == "__main__":
    raise SystemExit(main())
