import argparse
import math
import os
import random

from ai_shop import AIShopkeeper, ShopError
from demo import DemoShopkeeper, load_catalog
from items import STAT_LIMITS, money
from physics import Hole, MAX_STROKES, METERS_PER_YARD, calculate_shot, swing
from settings import has_key, load_env
from shop import Shop
from terminal import Terminal, WIDTH


MINIMAP_WIDTH = 18


STAT_LABELS = {
    "mass_kg": ("Mass", "kg"),
    "length_m": ("Length", "m"),
    "area_m2": ("Frontal area", "m2"),
    "loft_degrees": ("Face tilt", "deg"),
    "grip": ("Grip", "/ 1"),
    "rigidity": ("Rigidity", "/ 1"),
    "restitution": ("Bounciness", "/ 1"),
    "drag_coefficient": ("Air drag", ""),
    "rolling_resistance": ("Grass resistance", ""),
    "hardness": ("Hardness", "/ 1"),
    "durability_j": ("Durability", "J"),
}


def wallet_text(shop):
    return "INFINITE" if shop.infinite_money else money(shop.wallet)


def distance_text(distance_m, decimals=2):
    yards = distance_m / METERS_PER_YARD
    if math.isnan(yards):
        return "NaN yd"
    if math.isinf(yards):
        return "Infinity yd"
    return f"{yards:.{decimals}f} yd"


def ready_to_play(ui, shop):
    usable = sum(item.usable for item in shop.inventory)
    if usable >= 2:
        ui.write("play  head to the tee")
    else:
        ui.write(f"You'll need {2 - usable} more usable "
                 + ("item." if usable == 1 else "items."))
        ui.write("Anything can be a ball or a club.")


def line_item(items, key):
    try:
        index = int(key) - 1
    except (TypeError, ValueError):
        raise ValueError("Enter a line number.") from None
    if index < 0 or index >= len(items):
        raise ValueError("That line number was not found.")
    return items[index]


def receipt_items(shop):
    trade_ins = [item for item in shop.inventory if item.id in shop.selling]
    return shop.cart + trade_ins


def line_action(shop, verb, key):
    if verb == "sell":
        item = line_item(shop.inventory, key)
        kind = "sell"
    else:
        item = line_item(receipt_items(shop), key)
        if verb == "remove" and item not in shop.cart:
            raise ValueError("Use keep to cancel that trade-in.")
        if verb == "keep" and item.id not in shop.selling:
            raise ValueError("Use remove for that purchase.")
        kind = "unsell" if verb == "keep" else "remove"
    return {"kind": kind, "item_id": item.id, "item": None}


def show_inventory(ui, shop):
    ui.title("Your bag")
    if not shop.inventory:
        ui.write("Your bag is empty. Let's fix that.")
        ui.write("Order two items, then checkout.")
    receipt_lines = receipt_items(shop)
    for key, item in enumerate(shop.inventory, 1):
        ui.row(item.name, "", label_accent=item.ai_generated, prefix=f"{key}  ")
        status = f"{item.condition:.1f}%" if item.usable else "BROKEN"
        ui.row(f"  {status}", f"Resale {money(item.resale_cents)}")
        if item.id in shop.selling:
            receipt_key = receipt_lines.index(item) + 1
            ui.write(f"  On receipt / keep {receipt_key}")
    ui.rule()
    ui.row("Wallet", wallet_text(shop))
    if shop.inventory:
        ui.write("inspect #  take a closer look")


def show_item(ui, item, key=None):
    ui.title(f"Item {key}" if key is not None else "Item details")
    ui.write(item.name, accent=item.ai_generated)
    ui.write(item.description, accent=item.ai_generated)
    ui.row("Material", item.material, accent=item.ai_generated)
    ui.row("Price", money(item.price_cents), accent=item.ai_generated)
    ui.row("Resale", money(item.resale_cents))
    ui.row("Condition", f"{item.condition:.1f}%" if item.usable else "BROKEN")
    ui.rule()
    for key in STAT_LIMITS:
        label, unit = STAT_LABELS[key]
        ui.row(label, f"{getattr(item, key):.4g} {unit}".rstrip(), accent=item.ai_generated)


def inspect_item(ui, items, query):
    query = query.strip().casefold()
    if query.isdigit():
        try:
            item = line_item(items, query)
        except ValueError as error:
            ui.write(str(error))
            return
        show_item(ui, item, int(query))
        return
    matches = [(key, item) for key, item in enumerate(items, 1)
               if query in item.name.casefold()]
    if len(matches) != 1:
        ui.write("No single match. Try an item number.")
        return
    key, item = matches[0]
    show_item(ui, item, key)


def show_receipt(ui, shop):
    ui.title("Pro shop")
    if not shop.cart and not shop.selling:
        ui.row("Wallet", wallet_text(shop))
        ui.write("What can I get you?")
        if shop.inventory:
            ready_to_play(ui, shop)
        ui.write("help  commands / bag  your equipment")
        return
    ui.row("Pending receipt", "Not yet paid")
    ui.write(delay=0.06)
    key = 1
    for item in shop.cart:
        ui.row(item.name, money(item.price_cents), accent=item.ai_generated,
               label_accent=item.ai_generated, prefix=f"{key}  ")
        key += 1
    for item in shop.inventory:
        if item.id in shop.selling:
            ui.row(item.name, "-" + money(item.resale_cents),
                   label_accent=item.ai_generated, prefix=f"{key}  SELL ")
            key += 1
    ui.rule()
    ui.row("Total due" if shop.total >= 0 else "Shop pays", money(abs(shop.total)))
    ui.row("Wallet", wallet_text(shop))
    if not shop.infinite_money and shop.total > shop.wallet:
        ui.row("Over budget by", money(shop.total - shop.wallet))
        ui.write("remove #  trim your receipt")
    else:
        if not shop.infinite_money:
            ui.row("After checkout", money(shop.wallet - shop.total))
        ui.write(delay=0.08)
        ui.write("checkout  settle up")
        if shop.cart and shop.selling:
            ui.write("remove # / keep # / clear  edit")
        elif shop.selling:
            ui.write("keep # / clear  cancel a trade-in")
        else:
            ui.write("remove # / clear  change your order")


def shop_help(ui, keeper):
    ui.title("At the counter")
    ui.write("Order anything. Choose two different")
    ui.write("items to use as your ball and club.")
    ui.write()
    for command, meaning in (
        ("receipt", "Review your order"), ("bag", "Your equipment"),
        ("inspect #", "Item details"), ("remove #", "Remove an order item"),
        ("sell #", "Trade in a bag item"), ("keep #", "Cancel a trade-in"),
        ("clear", "Empty the receipt"), ("checkout", "Pay / collect items"),
        ("play", "Head to the tee"), ("provider", "Change shopkeeper"),
        ("quit", "Finish playing"),
    ):
        ui.row(command, meaning)
    ui.write()
    if keeper.provider == "demo":
        ui.write("Demo uses a fixed sample catalog.")
        ui.write("Type starter, lunch, or one name:")
        for item in load_catalog():
            ui.write("  " + item["name"])
    else:
        ui.write('Try "an egg and a sledgehammer".')
        ui.write('Then "remove the egg".')


def choose_provider(ui, requested=None):
    provider = requested
    while True:
        if not provider:
            ui.title("Shopkeeper")
            for name in ("openai", "anthropic"):
                ui.row(name, "key found" if has_key(name) else "no key")
            ui.row("demo", "Free / offline")
            provider = ui.ask("Choose a name above, or quit:").lower()
        if provider in ("quit", "q"):
            return None
        if provider == "demo":
            return DemoShopkeeper()
        if provider in ("openai", "anthropic"):
            try:
                keeper = AIShopkeeper(provider)
                return keeper
            except ShopError as error:
                ui.write(str(error))
        else:
            ui.write("Choose openai, anthropic, or demo.")
        provider = None


def select_equipment(ui, shop, role, other_id=None, current=None):
    choices = [item for item in shop.inventory if item.usable and item.id != other_id]
    if not choices:
        return None
    ui.title(f"Choose your {role}")
    ui.write("The object you'll hit." if role == "ball" else "The object you'll swing.")
    ui.write(delay=0.06)
    for key, item in enumerate(choices, 1):
        ui.row(item.name, f"{item.condition:.1f}%", label_accent=item.ai_generated,
               prefix=f"{key}  ")
    default = current if current in choices else choices[0] if len(choices) == 1 else None
    ui.write("inspect #  details / cancel  back")
    while True:
        suffix = f" / Enter for {choices.index(default) + 1}" if default else ""
        choice = ui.ask(f"Item number or name{suffix}:").strip()
        if choice.lower() in ("cancel", "back"):
            return None
        if choice.lower() in ("quit", "q", "exit"):
            raise EOFError
        if choice.lower().startswith("inspect "):
            inspect_item(ui, shop.inventory, choice.split(maxsplit=1)[1])
            continue
        if not choice and default:
            return default
        if choice.isdigit():
            try:
                return line_item(choices, choice)
            except ValueError:
                pass
        matches = [item for item in choices if choice and choice.casefold() in item.name.casefold()]
        if len(matches) == 1:
            return matches[0]
        ui.write("No single match. Try a number above.")


def show_course(ui, hole):
    if not math.isfinite(hole.position_m):
        lane = ["·"] * MINIMAP_WIDTH
        if math.isnan(hole.position_m):
            lane[len(lane) // 2] = "?"
            lane[-1] = "○"
        elif hole.position_m > 0:
            lane[0], lane[-1] = "○", "●"
        else:
            lane[0], lane[-1] = "●", "○"
        ui.row(distance_text(hole.remaining_m) + " to hole",
               f"Shot {hole.strokes + 1}/{MAX_STROKES}")
        ui.write()
        visual = "".join(lane)
        ui.visual(visual, visual.translate(str.maketrans("·○●", ".Oo")), center=True)
        ui.write()
        return
    left = min(0, hole.position_m)
    right = max(hole.length_m, hole.position_m, 1)
    lane = ["·"] * MINIMAP_WIDTH
    span = right - left
    cup = round((hole.length_m - left) / span * (len(lane) - 1))
    ball = round((hole.position_m - left) / span * (len(lane) - 1))
    # Nearby positions can round to one cell without actually being holed out.
    if ball == cup and not hole.complete:
        ball = cup - 1 if hole.position_m < hole.length_m else cup + 1
        ball = max(0, min(len(lane) - 1, ball))
        if ball == cup:
            cup = max(0, cup - 1)
    lane[cup] = "○"
    lane[ball] = "◎" if ball == cup else "●"
    ui.row(distance_text(hole.remaining_m) + " to hole", f"Shot {hole.strokes + 1}/{MAX_STROKES}")
    ui.write()
    ui.visual("".join(lane), "".join(lane).translate(str.maketrans("·○●◎", ".Oo@")), center=True)
    ui.write()


def course_help(ui):
    ui.title("On the course")
    if ui.manual_power or not ui.interactive:
        ui.write("Enter to swing, then type power.")
        ui.write("Use 0-100, or cancel to go back.")
    else:
        ui.write("Enter starts the meter.")
        ui.write("Enter again hits. Esc cancels.")
        ui.write("The meter rises, then falls.")
    ui.write("Lower power for shorter shots.")
    ui.write("Even a 0% swing uses a stroke.")
    ui.write()
    ui.row("ball / club", "Change equipment")
    ui.row("bag / inspect #", "Equipment details")
    ui.row("look", "Review your setup")
    ui.row("shop", "Leave with no prize")
    ui.row("quit", "Finish playing")
    ui.write()
    ui.write("Aim is automatic, even past the hole.")
    ui.write("Stop within 0.66 yd. Max 12 shots.")


def play_hole(ui, keeper, shop, round_number, rng):
    usable = [item for item in shop.inventory if item.usable]
    if len(usable) < 2:
        ui.write("Buy two usable items before playing.")
        ui.write("Order them here, then checkout.")
        return
    ball = select_equipment(ui, shop, "ball")
    if ball is None:
        return
    club = select_equipment(ui, shop, "club", ball.id)
    if club is None:
        return
    yards = rng.randint(120, 420)
    hole = Hole(yards * METERS_PER_YARD, 3 if yards < 220 else 4 if yards < 360 else 5)
    ui.title(f"Round {round_number} / Par {hole.par}")
    ui.row("Hole length", f"{yards} yd")
    ui.row("Ball", ball.name, accent=ball.ai_generated)
    ui.row("Club", club.name, accent=club.ai_generated)
    ui.visual("● = ball / ○ = hole / auto aim",
              "o = ball / O = hole / auto aim")
    while hole.strokes < MAX_STROKES:
        if not ball.usable or not club.usable:
            ui.write("Replace your broken equipment.")
            if len([item for item in shop.inventory if item.usable]) < 2:
                ui.write("Too few usable items. Round ended.")
                return
            if not ball.usable:
                ball = select_equipment(ui, shop, "ball", club.id if club.usable else None)
                if ball is None:
                    return
            if not club.usable:
                club = select_equipment(ui, shop, "club", ball.id)
                if club is None:
                    return
        show_course(ui, hole)
        preview = calculate_shot(ball, club, 1)
        ui.row("At 100% power", distance_text(preview.distance_m, 1))
        if preview.note != "A clean connection.":
            ui.write("Full power: " + preview.note)
        command = ui.ask(swing_prompt=True).lower()
        if command in ("quit", "q", "exit"):
            raise EOFError
        if command == "shop":
            ui.write("Round ended. No prize this time.")
            return
        if command in ("ball", "club"):
            other = club if command == "ball" else ball
            chosen = select_equipment(ui, shop, command, other.id,
                                      ball if command == "ball" else club)
            if chosen is not None:
                if command == "ball":
                    ball = chosen
                else:
                    club = chosen
                ui.row(command.capitalize(), chosen.name, accent=chosen.ai_generated)
            continue
        if command == "bag":
            show_inventory(ui, shop)
            continue
        if command in ("help", "?"):
            course_help(ui)
            continue
        if command == "look":
            ui.row("Ball", ball.name, accent=ball.ai_generated)
            ui.row("Club", club.name, accent=club.ai_generated)
            preview = calculate_shot(ball, club, 1)
            ui.row("Full power", distance_text(preview.distance_m, 1))
            ui.write(preview.note)
            continue
        if command.startswith("inspect "):
            inspect_item(ui, shop.inventory, command.split(maxsplit=1)[1])
            continue
        if command not in ("", "swing"):
            ui.write("Enter swings. Try help for commands.")
            continue
        power = ui.swing_meter()
        if power is None:
            continue
        before = hole.remaining_m
        shot = swing(ball, club, power)
        hole.hit(shot)
        ui.rule()
        sound = keeper.sound_effect(club.name, ball.name)
        ui.sound(sound, accent=getattr(keeper, "last_sound_generated", False))
        ui.row(f"{power:.0%} power", distance_text(shot.distance_m))
        if shot.ball_damage >= 1:
            ui.row("Ball condition", f"{ball.condition:.0f}%")
        if shot.club_damage >= 1:
            ui.row("Club condition", f"{club.condition:.0f}%")
        if shot.note != "A clean connection.":
            ui.write(shot.note)
        if hole.complete:
            shop.wallet += hole.prize_cents
            ui.pause(0.25)
            ui.center(hole.score_name)
            ui.rule()
            ui.row("Strokes", str(hole.strokes))
            ui.row("Prize", money(hole.prize_cents))
            ui.row("Wallet", wallet_text(shop))
            ui.write("Nicely played. Back to the counter.")
            return
        if shot.distance_m > before:
            ui.pause(0.15)
            ui.write("Past the hole. Aiming back now.")
        ui.pause(0.15)
    ui.write("Stroke limit reached. Back to shop.")


LOGO = """
┎┒  ┒┎┎┒             ┎
┨┒┎┒┃╂┃ ┎┒┰┰┒┰┰┒┎┒┰┒┎╂
┖┨┖┚┸┃┖┚┖┚┖┖┖┖┖┖┖┸┖┖┖┸
┖┚   ┚                
"""


def run_game(ui, keeper, rng):
    shop = Shop()
    round_number = 0
    ui.write()
    ui.art(LOGO, fallback="g o l f   e q u i p m e n t")
    ui.center("ANYTHING IS EQUIPMENT", delay=0.14)
    show_receipt(ui, shop)
    ui.write()
    ui.write("Pick two items. Checkout. Tee off.")
    if keeper.provider == "demo":
        ui.write('Try "starter" for a ball and club.')
        ui.write('Or "lunch" for something stranger.')
    else:
        ui.write('Try "and a sledgehammer".')
    while True:
        text = ui.ask()
        command = text.lower()
        if not command:
            continue
        if command in ("quit", "q", "exit"):
            return
        try:
            if command in ("cheat", "infinite money"):
                shop.infinite_money = True
                ui.write("Infinite money enabled.")
            elif command in ("cheat off", "finite money"):
                shop.infinite_money = False
                ui.write("Infinite money disabled.")
            elif command in ("help", "?"):
                shop_help(ui, keeper)
            elif command == "provider":
                selected = choose_provider(ui)
                if selected is not None:
                    keeper = selected
                    ui.row("Shopkeeper", keeper.provider)
                    if keeper.provider == "demo":
                        ui.write("Try starter, lunch, or help.")
            elif command == "bag":
                show_inventory(ui, shop)
            elif command == "receipt":
                show_receipt(ui, shop)
            elif command == "clear":
                shop.clear()
                show_receipt(ui, shop)
            elif command.startswith("inspect "):
                visible_items = receipt_items(shop) if shop.cart or shop.selling else shop.inventory
                inspect_item(ui, visible_items, text.split(maxsplit=1)[1])
            elif command.split()[0] in ("remove", "sell", "keep") and len(command.split()) == 2 and command.split()[1].isdigit():
                verb, key = command.split()
                action = line_action(shop, verb, key)
                shop.apply({"message": "", "actions": [action], "intent": "edit"})
                show_receipt(ui, shop)
            else:
                if command not in ("checkout", "play"):
                    if keeper.provider != "demo":
                        ui.write("The shopkeeper is writing a quote...", delay=0.08)
                    response = keeper.request(text, shop)
                    shop.apply(response, ai_generated=keeper.provider != "demo")
                    ui.write(response["message"], accent=keeper.provider != "demo")
                    show_receipt(ui, shop)
                    command = response["intent"] if not response["actions"] else "edit"
                if command == "checkout":
                    shop.checkout()
                    ui.title("Paid. Thank you.")
                    ui.row("Wallet", wallet_text(shop))
                    ready_to_play(ui, shop)
                elif command == "play":
                    if shop.cart or shop.selling:
                        ui.write("Checkout or clear the receipt first.")
                    else:
                        round_number += 1
                        play_hole(ui, keeper, shop, round_number, rng)
                        show_receipt(ui, shop)
                elif command == "help":
                    shop_help(ui, keeper)
        except (ValueError, ShopError) as error:
            ui.write(str(error))


def main():
    parser = argparse.ArgumentParser(description="GOLF: anything is equipment.")
    parser.add_argument("--demo", action="store_true", help="Use the free offline catalog.")
    parser.add_argument("--provider", choices=["openai", "anthropic"])
    parser.add_argument("--fast", action="store_true", help="Disable printing delays.")
    parser.add_argument("--manual-power", action="store_true", help="Type power instead of timing it.")
    parser.add_argument("--seed", type=int, help="Repeat the same course sequence.")
    args = parser.parse_args()
    load_env()
    ui = Terminal(fast=args.fast, manual_power=args.manual_power)
    try:
        provider = "demo" if args.demo else args.provider or os.environ.get("GOLF_PROVIDER", "").lower()
        keeper = choose_provider(ui, provider)
        if keeper is not None:
            run_game(ui, keeper, random.Random(args.seed))
    except (EOFError, KeyboardInterrupt):
        ui.write()
    finally:
        ui.write("Thanks for playing.")
        ui.close()


if __name__ == "__main__":
    main()
