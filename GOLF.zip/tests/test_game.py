from contextlib import redirect_stdout
from dataclasses import asdict, replace
from io import StringIO
import json
import math
import os
from pathlib import Path
import random
import re
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from demo import DemoShopkeeper, load_catalog
from GOLF import (LOGO, inspect_item, line_action, select_equipment, show_course,
                  show_inventory, show_item, show_receipt)
from items import Item, STAT_LIMITS, dollars_to_cents, money
from physics import (Hole, METERS_PER_YARD, Shot, calculate_shot, stopping_distance, swing)
from settings import ROOT, has_key, load_env
from shop import MAX_ITEMS, Shop
from terminal import (ACCENT, LINE_WIDTH, MARGIN, METER_HALF_CYCLE, WHITE, WIDTH,
                      Terminal, meter_line, meter_power)


CATALOG = {item["name"]: item for item in load_catalog()}


def item(name, item_id="ball"):
    return Item.from_generated(CATALOG[name], item_id)


def add(name):
    return {"kind": "add", "item_id": "", "item": CATALOG[name].copy()}


def change(kind, item_id):
    return {"kind": kind, "item_id": item_id, "item": None}


def quote(*actions):
    return {"message": "Coming right up.", "intent": "edit", "actions": list(actions)}


class PhysicsTests(unittest.TestCase):
    def setUp(self):
        self.ball = item("Golf Ball")
        self.driver = item("Golf Club", "club")

    def test_standard_equipment_ranges_and_power_control(self):
        ranges = {"Golf Club": (230, 360), "7-Iron": (130, 260),
                  "Sand Wedge": (25, 140), "Putter": (100, 330)}
        for name, (low, high) in ranges.items():
            with self.subTest(club=name):
                club = item(name, "club")
                distances = [calculate_shot(self.ball, club, p).distance_m / METERS_PER_YARD
                             for p in (0, 0.01, 0.05, 0.1, 0.5, 1)]
                self.assertEqual(distances, sorted(distances))
                self.assertGreater(distances[-1], low)
                self.assertLess(distances[-1], high)
                self.assertTrue(calculate_shot(self.ball, club, 1).ball_damage < 2)

    def test_iron_and_wedge_have_shorter_forward_shots(self):
        distances = [calculate_shot(self.ball, item(name, "club"), 1).distance_m
                     for name in ("Golf Club", "7-Iron", "Sand Wedge")]
        self.assertGreater(distances[0], distances[1])
        self.assertGreater(distances[1], distances[2])

    def test_flexible_noodle_cannot_launch_a_long_drive(self):
        noodle = item("Pool Noodle", "club")
        for power in (0.5, 0.97, 1):
            with self.subTest(power=power):
                shot = calculate_shot(self.ball, noodle, power)
                self.assertGreater(shot.distance_m, 0)
                self.assertLess(shot.distance_m, 2)
        for rigidity in (0.01, 0.03, 0.05, 0.1):
            with self.subTest(rigidity=rigidity):
                flexible = replace(noodle, name="An unnamed flexible tube", rigidity=rigidity)
                self.assertLess(calculate_shot(self.ball, flexible, 1).distance_m, 10)

    def test_compliance_limits_transfer_in_both_roles(self):
        noodle = item("Pool Noodle", "club")
        flexible = calculate_shot(self.ball, noodle, 1)
        rigid = calculate_shot(self.ball, replace(noodle, rigidity=1), 1)
        self.assertLess(flexible.ball_speed, rigid.ball_speed * 0.05)
        rigid_target = calculate_shot(self.ball, self.driver, 1)
        soft_target = calculate_shot(replace(self.ball, rigidity=0.03), self.driver, 1)
        self.assertLess(soft_target.ball_speed, rigid_target.ball_speed * 0.05)

    def test_short_objects_cannot_reach_driver_head_speed(self):
        marble = replace(self.ball, id="club", name="Glass Marble", mass_kg=0.02,
                         length_m=0.016, area_m2=0.0002, grip=0.2,
                         rigidity=0.9, restitution=0.4, durability_j=30)
        marble_shot = calculate_shot(self.ball, marble, 1)
        driver_shot = calculate_shot(self.ball, self.driver, 1)
        self.assertLess(marble_shot.club_speed, 15)
        self.assertLess(marble_shot.distance_m, 10)
        self.assertGreater(driver_shot.club_speed, marble_shot.club_speed * 2)

    def test_putter_can_make_fine_adjustments(self):
        putter = item("Putter", "club")
        short = calculate_shot(self.ball, putter, 0.01).distance_m
        longer = calculate_shot(self.ball, putter, 0.05).distance_m
        self.assertGreater(short, 0)
        self.assertLess(short, 0.5)
        self.assertGreater(longer, short)
        self.assertLess(longer, 5)

    def test_normal_equipment_lasts_a_round_and_degrades(self):
        old_value = self.ball.resale_cents
        first = calculate_shot(self.ball, self.driver, 1).distance_m
        for _ in range(12):
            swing(self.ball, self.driver, 1)
        self.assertGreater(self.ball.condition, 80)
        self.assertLess(self.ball.condition, 100)
        self.assertLess(self.driver.condition, 100)
        self.assertLess(self.ball.resale_cents, old_value)
        self.assertLess(calculate_shot(self.ball, self.driver, 1).distance_m, first)

    def test_egg_and_lightbulb_shatter(self):
        for name in ("Raw Egg", "Lightbulb"):
            with self.subTest(ball=name):
                ball, hammer = item(name), item("Sledgehammer", "club")
                shot = swing(ball, hammer, 1)
                self.assertFalse(ball.usable)
                self.assertTrue(shot.ball_broken)
                self.assertEqual(shot.distance_m, 0)
                self.assertGreater(hammer.condition, 99)

    def test_party_balloon_pops_under_a_driver(self):
        balloon = item("Party Balloon")
        shot = calculate_shot(balloon, self.driver, 0.5)
        self.assertTrue(shot.ball_broken)
        self.assertEqual(shot.distance_m, 0)

    def test_diamond_survives_many_hammer_hits(self):
        diamond, hammer = item("Diamond"), item("Sledgehammer", "club")
        for _ in range(12):
            swing(diamond, hammer, 1)
        self.assertGreater(diamond.condition, 50)
        self.assertLess(diamond.condition, 100)

    def test_egg_survives_a_gentle_tap(self):
        egg = item("Raw Egg")
        shot = swing(egg, item("Sledgehammer", "club"), 0.1)
        self.assertTrue(egg.usable)
        self.assertGreater(shot.distance_m, 0)

    def test_fragile_club_breaks_and_limits_transfer(self):
        egg = item("Raw Egg", "club")
        shot = swing(self.ball, egg, 1)
        self.assertFalse(egg.usable)
        self.assertTrue(self.ball.usable)
        self.assertLess(shot.distance_m, 10)

    def test_roles_can_be_swapped(self):
        self.assertGreater(calculate_shot(self.driver, self.ball, 1).distance_m, 0)

    def test_sun_keeps_its_scale_and_cannot_be_swung(self):
        sun = item("The Sun", "sun")
        self.assertGreater(sun.mass_kg, 1e30)
        self.assertEqual(calculate_shot(self.ball, sun, 1).distance_m, 0)
        self.assertLess(calculate_shot(sun, self.driver, 1).distance_m, 1e-10)

    def test_subatomic_items_and_infinite_properties_are_allowed(self):
        electron_data = CATALOG["Golf Ball"] | {
            "name": "Electron", "description": "A single elementary particle.",
            "material": "Elementary particle", "price_usd": 0.01,
            "mass_kg": 9.1093837139e-31, "length_m": 0, "area_m2": 0,
            "rolling_resistance": 0.01, "hardness": 0, "durability_j": 1e-30,
        }
        electron = Item.from_generated(electron_data, "electron")
        self.assertEqual(electron.mass_kg, 9.1093837139e-31)
        self.assertTrue(all(math.isfinite(value) for value in (
            calculate_shot(electron, self.driver, 1).distance_m,
            calculate_shot(self.ball, replace(electron, id="electron-club"), 1).distance_m,
            calculate_shot(electron, replace(electron, id="second-electron"), 1).distance_m,
        )))

        infinite_data = CATALOG["Golf Club"] | {
            "name": "Unstoppable Force", "mass_kg": "Infinity",
            "length_m": "Infinity", "durability_j": "Infinity",
        }
        force = Item.from_generated(infinite_data, "force")
        self.assertTrue(math.isinf(force.mass_kg))
        self.assertTrue(math.isnan(calculate_shot(self.ball, force, 1).distance_m))
        immense = Item.from_generated(infinite_data | {"mass_kg": 10 ** 1000}, "immense")
        self.assertTrue(math.isinf(immense.mass_kg))

    def test_zero_resistance_travels_forever(self):
        frictionless = replace(self.ball, rolling_resistance=0)
        self.assertEqual(stopping_distance(frictionless, 0), 0)
        self.assertTrue(math.isinf(stopping_distance(frictionless, 5)))

    def test_mass_drag_and_grip_change_outcomes(self):
        base = calculate_shot(self.ball, self.driver, 1).distance_m
        self.assertLess(calculate_shot(replace(self.ball, mass_kg=7), self.driver, 1).distance_m, base)
        self.assertLess(calculate_shot(replace(self.ball, area_m2=0.1), self.driver, 1).distance_m, base)
        self.assertLess(calculate_shot(self.ball, replace(self.driver, grip=0.1), 1).distance_m, base)

    def test_preview_does_not_damage_items(self):
        before = (asdict(self.ball), asdict(self.driver))
        self.assertEqual(calculate_shot(self.ball, self.driver, 0.5),
                         calculate_shot(self.ball, self.driver, 0.5))
        self.assertEqual(before, (asdict(self.ball), asdict(self.driver)))

    def test_zero_power_and_zero_drag(self):
        shot = swing(self.ball, self.driver, 0)
        self.assertEqual(shot.distance_m, 0)
        self.assertEqual(self.ball.condition, 100)
        self.assertAlmostEqual(stopping_distance(replace(self.ball, drag_coefficient=0), 5),
                               25 / (2 * self.ball.rolling_resistance * 9.81))

    def test_invalid_power_and_equipment(self):
        for power in (-0.1, 1.1, float("nan"), float("inf"), True):
            with self.assertRaises(ValueError):
                calculate_shot(self.ball, self.driver, power)
        with self.assertRaises(ValueError):
            calculate_shot(self.ball, self.ball, 0.5)
        with self.assertRaises(ValueError):
            calculate_shot(replace(self.ball, condition=0), self.driver, 0.5)

    def test_every_sample_pair_is_finite_and_energy_bounded(self):
        for ball_name in CATALOG:
            for club_name in CATALOG:
                ball, club = item(ball_name), item(club_name, "club")
                for power in (0, 0.01, 0.1, 0.5, 1):
                    with self.subTest(ball=ball_name, club=club_name, power=power):
                        shot = calculate_shot(ball, club, power)
                        for value in (shot.distance_m, shot.ball_speed, shot.club_speed,
                                      shot.ball_damage, shot.club_damage):
                            self.assertTrue(math.isfinite(value) and value >= 0)
                        self.assertLessEqual(shot.ball_damage, 100)
                        self.assertLessEqual(shot.club_damage, 100)
                        outgoing = 0.5 * ball.mass_kg * shot.ball_speed ** 2
                        incoming = 0.5 * club.mass_kg * shot.club_speed ** 2
                        self.assertLessEqual(outgoing, incoming + 1e-8)

    def test_extreme_generated_stats_stay_finite(self):
        rng = random.Random(6)
        for _ in range(300):
            pair = []
            for item_id in ("ball", "club"):
                data = CATALOG["Golf Ball"].copy()
                for key, (low, high, _) in STAT_LIMITS.items():
                    data[key] = (10 ** rng.uniform(math.log10(low), math.log10(high))
                                 if low > 0 else rng.uniform(low, high))
                pair.append(Item.from_generated(data, item_id))
            shot = calculate_shot(*pair, rng.random())
            self.assertTrue(all(math.isfinite(value) and value >= 0 for value in
                                (shot.distance_m, shot.ball_damage, shot.club_damage)))


class ShopTests(unittest.TestCase):
    def setUp(self):
        self.shop = Shop()

    def test_lunch_receipt_replace_and_remove(self):
        self.shop.apply(quote(add("Double Cheeseburger (Plain)"), add("Small Dr. Pepper"), add("French Fries")))
        original = self.shop.cart[0]
        large = CATALOG["Small Dr. Pepper"] | {"name": "Large Dr. Pepper", "price_usd": 3, "mass_kg": 0.7}
        self.shop.apply(quote({"kind": "replace", "item_id": "02", "item": large}))
        self.assertIs(self.shop.cart[0], original)
        self.assertEqual(self.shop.cart[1].name, "Large Dr. Pepper")
        self.shop.apply(quote(change("remove", "03")))
        self.assertEqual(len(self.shop.cart), 2)
        self.assertEqual(self.shop.total, 850)

    def test_checkout_and_used_resale(self):
        self.shop.apply(quote(add("Golf Ball"), add("Golf Club")))
        self.assertEqual(self.shop.wallet, 50_000)
        self.assertEqual(self.shop.inventory, [])
        self.shop.checkout()
        self.assertEqual(self.shop.wallet, 43_200)
        self.shop.inventory[1].condition = 50
        self.shop.apply(quote(change("sell", "02")))
        self.assertEqual(self.shop.sale_total, 1950)
        self.assertEqual(len(self.shop.inventory), 2)
        self.shop.checkout()
        self.assertEqual(self.shop.wallet, 45_150)
        self.assertEqual(len(self.shop.inventory), 1)

    def test_unaffordable_sun_does_not_change_ownership(self):
        self.shop.apply(quote(add("The Sun")))
        with self.assertRaises(ValueError):
            self.shop.checkout()
        self.assertEqual(self.shop.wallet, 50_000)
        self.assertEqual(self.shop.inventory, [])
        self.assertEqual(len(self.shop.cart), 1)

    def test_infinite_money_allows_debug_purchases_without_changing_wallet(self):
        self.shop.infinite_money = True
        self.shop.apply(quote(add("The Sun")))
        self.shop.checkout()
        self.assertEqual(self.shop.wallet, 50_000)
        self.assertEqual(self.shop.inventory[0].name, "The Sun")

    def test_sales_can_fund_purchases(self):
        self.shop.apply(quote(add("Golf Club")))
        self.shop.checkout()
        self.shop.wallet = 0
        self.shop.apply(quote(change("sell", "01"), add("Golf Ball")))
        self.shop.checkout()
        self.assertEqual(self.shop.wallet, 3600)
        self.assertEqual(self.shop.inventory[0].name, "Golf Ball")

    def test_clear_and_unsell_preserve_equipment(self):
        self.shop.apply(quote(add("Golf Club")))
        self.shop.checkout()
        self.shop.apply(quote(change("sell", "01")))
        self.shop.apply(quote(change("unsell", "01")))
        self.assertEqual(self.shop.selling, [])
        self.shop.apply(quote(change("sell", "01"), add("Golf Ball")))
        self.shop.clear()
        self.assertEqual(self.shop.wallet, 43_500)
        self.assertEqual(len(self.shop.inventory), 1)

    def test_invalid_batch_rolls_back_everything(self):
        before = asdict(self.shop)
        with self.assertRaises(ValueError):
            self.shop.apply(quote(add("Golf Ball"), change("remove", "99")), ai_generated=True)
        self.assertEqual(asdict(self.shop), before)
        self.assertEqual(self.shop.next_id, 1)

    def test_item_origin_survives_checkout_and_cached_quotes_from_another_provider(self):
        self.shop.apply(quote(add("Golf Ball")), ai_generated=True)
        self.shop.apply(quote(add("Golf Club")))
        self.shop.checkout()
        self.assertEqual([thing.ai_generated for thing in self.shop.inventory], [True, False])
        self.shop.apply(quote(add("Golf Ball")))
        self.shop.apply(quote(add("Golf Club")), ai_generated=True)
        self.assertEqual([thing.ai_generated for thing in self.shop.cart], [True, False])

    def test_invalid_generated_numbers_are_rejected(self):
        for key, value in (("mass_kg", -1), ("mass_kg", True),
                           ("mass_kg", float("nan")), ("mass_kg", -float("inf")), ("price_usd", -1),
                           ("price_usd", float("inf")), ("grip", float("nan")),
                           ("durability_j", 0), ("rigidity", "hard")):
            with self.subTest(field=key, value=value), self.assertRaises(ValueError):
                Item.from_generated(CATALOG["Golf Ball"] | {key: value}, "01")

    def test_bad_or_extra_fields_are_rejected(self):
        for action in (add("Golf Ball") | {"item_id": "invented"},
                       change("delete", "01"), change("sell", "99"),
                       {"kind": "add"}):
            with self.assertRaises(ValueError):
                self.shop.apply(quote(action))
        with self.assertRaises(ValueError):
            self.shop.apply(quote() | {"wallet": 1000000})
        with self.assertRaises(ValueError):
            Item.from_generated(CATALOG["Golf Ball"] | {"condition": 100000}, "01")

    def test_cached_price_and_duplicate_objects(self):
        self.shop.apply(quote(add("Golf Ball")))
        cheaper = add("Golf Ball")
        cheaper["item"]["price_usd"] = 0.01
        self.shop.apply(quote(cheaper))
        self.assertEqual(self.shop.cart[1].price_cents, 300)
        self.assertNotEqual(self.shop.cart[0].id, self.shop.cart[1].id)
        self.shop.cart[0].damage(50)
        self.assertEqual(self.shop.cart[1].condition, 100)

    def test_no_duplicate_sale_or_repeat_checkout(self):
        self.shop.apply(quote(add("Golf Ball")))
        self.shop.checkout()
        with self.assertRaises(ValueError):
            self.shop.checkout()
        with self.assertRaises(ValueError):
            self.shop.apply(quote(change("sell", "01"), change("sell", "01")))
        self.assertEqual(self.shop.selling, [])

    def test_broken_items_have_no_resale_value(self):
        ball = item("Golf Ball")
        ball.damage(10000)
        self.assertEqual(ball.condition, 0)
        self.assertEqual(ball.resale_cents, 0)

    def test_cart_capacity_is_atomic(self):
        for _ in range(MAX_ITEMS // 20):
            self.shop.apply(quote(*[add("Golf Ball") for _ in range(20)]))
        with self.assertRaises(ValueError):
            self.shop.apply(quote(add("Golf Ball")))
        self.assertEqual(len(self.shop.cart), MAX_ITEMS)

    def test_money_rounding_and_astronomical_resale(self):
        self.assertEqual(dollars_to_cents(1.005), 101)
        self.assertEqual(dollars_to_cents(1e30), 10 ** 32)
        self.assertEqual(item("The Sun").resale_cents, 6 * 10 ** 31)
        self.assertEqual(money(-123), "-$1.23")
        self.assertLessEqual(len(money(10 ** 62)), 12)


class CourseAndInterfaceTests(unittest.TestCase):
    def test_overshoot_reverses_direction(self):
        hole = Hole(100, 3)
        hole.hit(Shot(120, 10, 20, 0, 0, ""))
        self.assertEqual(hole.remaining_m, 20)
        self.assertFalse(hole.complete)
        hole.hit(Shot(19.7, 10, 20, 0, 0, ""))
        self.assertTrue(hole.complete)
        self.assertEqual(hole.position_m, 100)

    def test_prize_depends_on_performance(self):
        self.assertEqual(Hole(100, 3).prize_cents, 0)
        prizes = [Hole(100, 3, strokes=n, complete=True).prize_cents for n in (1, 2, 3, 5, 12)]
        self.assertEqual(prizes, sorted(prizes, reverse=True))
        self.assertGreater(prizes[-1], 0)

    def test_broken_ball_and_zero_swing_cannot_win(self):
        hole = Hole(0.5, 3)
        hole.hit(Shot(0.5, 1, 1, 1, 0, "", ball_broken=True))
        self.assertFalse(hole.complete)
        hole.hit(Shot(0, 0, 0, 0, 0, ""))
        self.assertFalse(hole.complete)

    def test_meter_runs_up_down_and_stays_short(self):
        times = [0, METER_HALF_CYCLE / 2, METER_HALF_CYCLE,
                 METER_HALF_CYCLE * 1.5, METER_HALF_CYCLE * 2]
        self.assertEqual([meter_power(t) for t in times], [0, 0.5, 1, 0.5, 0])
        self.assertEqual(meter_line(1), "▌" * WIDTH)
        self.assertEqual(meter_line(0.5, rising=False), "▌" * 18 + "·" * 18)
        self.assertEqual(len(meter_line(1)), WIDTH)
        for tick in range(1001):
            power = meter_power(tick / 100)
            self.assertTrue(0 <= power <= 1)
            self.assertLessEqual(len(meter_line(power)), 36)

    def test_manual_meter_rejects_nonfinite_input(self):
        ui = Terminal(fast=True, manual_power=True)
        with patch.object(ui, "ask", side_effect=["nan", "inf", "101", "25"]), redirect_stdout(StringIO()):
            self.assertEqual(ui.swing_meter(), 0.25)

    def test_meter_replaces_the_prompt_without_a_new_line(self):
        ui = Terminal(fast=True)
        ui.interactive, ui.color = True, False
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output):
            keyboard.return_value.__enter__.return_value.side_effect = ["\r", "\r"]
            self.assertEqual(ui.ask(swing_prompt=True), "")
            self.assertNotIn("\n", output.getvalue())
            ui.swing_meter()
        self.assertEqual(output.getvalue().count("\n"), 4)
        self.assertIn("·" * WIDTH, output.getvalue())
        self.assertIn("\n\n", output.getvalue())

    def test_meter_locks_power_at_keypress_and_escape_returns_without_a_stroke(self):
        ui = Terminal(fast=True)
        ui.interactive, ui.color = True, False
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output), \
                patch("terminal.time.monotonic", side_effect=[0, 0.5, 1.125]):
            keyboard.return_value.__enter__.return_value.return_value = "\r"
            self.assertEqual(ui.swing_meter(), 0.75)
        self.assertIn("▌" * 27 + "·" * 9, output.getvalue())
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output):
            keyboard.return_value.__enter__.return_value.return_value = "\x1b"
            self.assertIsNone(ui.swing_meter())
        self.assertIn("No stroke used.", output.getvalue())
        self.assertEqual(output.getvalue().count("\n"), 4)

    def test_long_requests_scroll_without_losing_text(self):
        ui = Terminal(fast=True)
        ui.interactive, ui.color = True, False
        request = "A double cheeseburger, plain, a large Dr. Pepper, and fries. Actually, make that a small."
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output):
            keyboard.return_value.__enter__.return_value.side_effect = [*request, "\r"]
            self.assertEqual(ui.ask(), request)
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in output.getvalue().replace("\n", "").split("\r")))

    def test_player_input_is_green_but_prompt_and_meter_are_white(self):
        ui = Terminal(fast=True)
        ui.interactive, ui.color = True, True
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output):
            keyboard.return_value.__enter__.return_value.side_effect = ["b", "a", "x", "\x08", "g", "\r"]
            self.assertEqual(ui.ask(), "bag")
        self.assertIn(WHITE + "> " + WHITE + ACCENT + "bag" + WHITE, output.getvalue())
        output = StringIO()
        with patch("terminal.keyboard") as keyboard, redirect_stdout(output):
            keyboard.return_value.__enter__.return_value.return_value = "\r"
            ui.swing_meter()
        self.assertNotIn(ACCENT, output.getvalue())

    def test_unicode_art_is_preserved(self):
        ui = Terminal(fast=True)
        ui.color = False
        output = StringIO()
        with redirect_stdout(output):
            ui.art(LOGO)
        lines = output.getvalue().splitlines()
        original = LOGO.strip("\n").splitlines()
        inset = " " * ((WIDTH - max(map(len, original))) // 2)
        self.assertEqual(lines, [MARGIN + inset + line.rstrip() for line in original])
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in lines))

    def test_sound_has_margin_and_pauses_before_results(self):
        ui = Terminal(fast=True)
        ui.color = False
        output = StringIO()
        with redirect_stdout(output), patch("terminal.time.sleep") as sleep:
            ui.sound("*thwack!*")
            sleep.assert_not_called()
            ui.delay = 0.025
            ui.sound("*thwack!*")
            sleep.assert_any_call(0.55)
            ui.row("97% power", "0.62 yd")
        self.assertTrue(output.getvalue().startswith("\n" + MARGIN + "THWACK!".center(WIDTH).rstrip() + "\n\n"))
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in output.getvalue().splitlines()))

    def test_receipt_stats_and_course_fit_36_columns_plus_margin(self):
        shop = Shop()
        shop.apply(quote(add("Double Cheeseburger (Plain)"), add("The Sun")))
        shop.cart[0].name = "A" * 80
        ui = Terminal(fast=True)
        ui.color = False
        output = StringIO()
        with redirect_stdout(output):
            show_receipt(ui, shop)
            show_inventory(ui, shop)
            for thing in shop.cart:
                show_item(ui, thing)
            for position in (-10000, 0, 99.9, 20000):
                show_course(ui, Hole(100, 3, position_m=position))
            ui.write("\x1b[31m untrusted\ttext\n" + "word " * 80)
        lines = output.getvalue().splitlines()
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in lines))
        self.assertTrue(all(not line or line.startswith(MARGIN) for line in lines))
        self.assertNotIn("\x1b", output.getvalue())

    def test_only_generated_fields_are_green_in_receipts_bags_and_details(self):
        shop = Shop()
        shop.apply(quote(add("Golf Ball")), ai_generated=True)
        shop.apply(quote(add("Golf Club")))
        ui = Terminal(fast=True)
        ui.color = True
        green_pattern = re.escape(ACCENT) + "(.*?)" + re.escape(WHITE)
        output = StringIO()
        with redirect_stdout(output):
            show_receipt(ui, shop)
        self.assertEqual(re.findall(green_pattern, output.getvalue()), ["Golf Ball", "$3.00"])
        shop.checkout()
        output = StringIO()
        with redirect_stdout(output):
            show_inventory(ui, shop)
        self.assertEqual(re.findall(green_pattern, output.getvalue()), ["Golf Ball"])
        output = StringIO()
        with redirect_stdout(output):
            show_item(ui, shop.inventory[0])
        green = re.findall(green_pattern, output.getvalue())
        self.assertIn("0.0459 kg", green)
        self.assertNotIn("Mass", green)
        self.assertNotIn("100.0%", green)
        self.assertNotIn("$1.80", green)

    def test_visible_line_numbers_reindex_after_removal(self):
        shop = Shop()
        shop.apply(quote(add("Golf Ball"), add("Golf Club"), add("Raw Egg")))
        shop.apply(quote(change("remove", "01")))
        self.assertEqual([item.id for item in shop.cart], ["02", "03"])
        output = StringIO()
        ui = Terminal(fast=True)
        ui.color = False
        with redirect_stdout(output):
            show_receipt(ui, shop)
        self.assertIn("1  Golf Club", output.getvalue())
        self.assertIn("2  Raw Egg", output.getvalue())
        self.assertNotIn("02  Golf Club", output.getvalue())
        self.assertEqual(line_action(shop, "remove", "1")["item_id"], "02")

    def test_bag_receipt_and_equipment_lists_use_their_visible_positions(self):
        shop = Shop()
        shop.apply(quote(add("Golf Ball"), add("Golf Club"), add("Raw Egg")))
        shop.checkout()
        shop.inventory[0].condition = 0
        shop.apply(quote(change("sell", "02")))
        self.assertEqual(line_action(shop, "sell", "3")["item_id"], "03")
        self.assertEqual(line_action(shop, "keep", "1")["item_id"], "02")
        ui = Terminal(fast=True)
        ui.color = False
        output = StringIO()
        with redirect_stdout(output), patch.object(ui, "ask", return_value="1"):
            selected = select_equipment(ui, shop, "ball")
        self.assertIs(selected, shop.inventory[1])
        self.assertIn("1  Golf Club", output.getvalue())
        self.assertIn("2  Raw Egg", output.getvalue())

    def test_course_keeps_ball_and_hole_distinct_until_complete(self):
        ui = Terminal(fast=True)
        ui.color = False
        for position in (99, 100.1, 101, 20000):
            output = StringIO()
            with redirect_stdout(output):
                show_course(ui, Hole(100, 3, position_m=position))
            lane = next(line for line in output.getvalue().splitlines() if "●" in line)
            self.assertIn("●", lane)
            self.assertIn("○", lane)
            if position < 100:
                self.assertLess(lane.index("●"), lane.index("○"))
            else:
                self.assertGreater(lane.index("●"), lane.index("○"))
            lines = output.getvalue().splitlines()
            lane_index = lines.index(lane)
            self.assertEqual(lines[lane_index - 1], "")
            self.assertEqual(lines[lane_index + 1], "")

    def test_course_can_print_an_undefined_ball_position(self):
        ui = Terminal(fast=True)
        ui.color = False
        for position, label in ((float("nan"), "NaN yd"), (float("inf"), "Infinity yd")):
            output = StringIO()
            with redirect_stdout(output):
                show_course(ui, Hole(100, 3, position_m=position))
            self.assertIn(label, output.getvalue())

    def test_equipment_accepts_unique_names_defaults_and_cancel(self):
        shop = Shop()
        shop.apply(quote(add("Golf Ball"), add("Golf Club")))
        shop.checkout()
        ui = Terminal(fast=True)
        with patch.object(ui, "ask", side_effect=["golf", "ball"]), redirect_stdout(StringIO()):
            self.assertIs(select_equipment(ui, shop, "ball"), shop.inventory[0])
        with patch.object(ui, "ask", return_value=""), redirect_stdout(StringIO()):
            self.assertIs(select_equipment(ui, shop, "club", other_id="01"), shop.inventory[1])
        with patch.object(ui, "ask", return_value="cancel"), redirect_stdout(StringIO()):
            self.assertIsNone(select_equipment(ui, shop, "ball"))

    def test_inspect_accepts_ids_and_unique_names(self):
        items = [item("Golf Ball", "01"), item("Pool Noodle", "02")]
        ui = Terminal(fast=True)
        ui.color = False
        for query in ("2", "02", "pool noodle", "noodle"):
            output = StringIO()
            with redirect_stdout(output):
                inspect_item(ui, items, query)
            self.assertIn("Pool Noodle", output.getvalue())

    def test_dotenv_preserves_environment_and_handles_quotes(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            path = Path(folder) / ".env"
            path.write_text('\ufeff# test\nOPENAI_API_KEY="sample-secret"\nGOLF_PROVIDER=anthropic # note\n', encoding="utf-8")
            with patch.dict(os.environ, {"GOLF_PROVIDER": "openai"}, clear=True):
                load_env(path)
                self.assertEqual(os.environ["OPENAI_API_KEY"], "sample-secret")
                self.assertEqual(os.environ["GOLF_PROVIDER"], "openai")
                self.assertTrue(has_key("openai"))
            with patch.dict(os.environ, {"OPENAI_API_KEY": "paste-your-key"}, clear=True):
                self.assertFalse(has_key("openai"))

    def test_complete_game_then_sell_used_equipment(self):
        yards = random.Random(1).randint(120, 420)
        ball, club = item("Golf Ball"), item("Golf Club", "club")
        low, high = 0, 1
        for _ in range(50):
            middle = (low + high) / 2
            if calculate_shot(ball, club, middle).distance_m < yards * METERS_PER_YARD:
                low = middle
            else:
                high = middle
        commands = ["starter", "checkout", "play", "1", "1", "", str(high * 100),
                    "sell 1", "checkout", "bag", "quit"]
        result = subprocess.run([sys.executable, str(ROOT / "GOLF.py"), "--demo", "--fast", "--seed", "1"],
                                input="\n".join(commands) + "\n", text=True, capture_output=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Hole in one!", result.stdout)
        self.assertIn("$300.00", result.stdout)
        self.assertTrue(any(sound in result.stdout for sound in DemoShopkeeper.sounds))
        self.assertIn("SELL Golf Ball", result.stdout)
        self.assertIn("Thanks for playing.", result.stdout)
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in result.stdout.splitlines()))

    def test_no_key_startup_and_offline_escape(self):
        environment = os.environ | {"OPENAI_API_KEY": "", "ANTHROPIC_API_KEY": "", "GOLF_PROVIDER": ""}
        result = subprocess.run([sys.executable, str(ROOT / "GOLF.py"), "--fast"], env=environment,
                                input="openai\ndemo\nquit\n", text=True, capture_output=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Add OPENAI_API_KEY to .env.", result.stdout)
        self.assertIn("Wallet", result.stdout)


if __name__ == "__main__":
    unittest.main()
