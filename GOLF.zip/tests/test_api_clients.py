import importlib.util
import json
import os
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from ai_shop import AIShopkeeper, SHOP_PROMPT, SHOP_SCHEMA, ShopError, internalize_line_numbers
from shop import Shop
from tests.test_game import add, quote


SDK_INSTALLED = all(importlib.util.find_spec(name) is not None for name in ("openai", "anthropic", "httpx"))


@unittest.skipUnless(SDK_INSTALLED, "Install the API clients to test their HTTP adapters.")
class APIClientTests(unittest.TestCase):
    def request_with_response(self, provider, status=200, incomplete=False, payload=None, shop=None):
        import httpx
        from anthropic import Anthropic
        from openai import OpenAI
        expected = quote(add("Golf Ball"))
        raw = json.dumps(expected) if payload is None else payload
        captured = []

        def handle(request):
            captured.append(json.loads(request.content))
            if status != 200:
                return httpx.Response(status, json={"error": {"type": "test_error", "message": "secret-value"}})
            if provider == "openai":
                data = {"id": "resp_test", "object": "response", "created_at": 0,
                        "status": "incomplete" if incomplete else "completed", "model": "gpt-4.1-mini",
                        "output": [{"type": "message", "id": "msg_test", "role": "assistant",
                                    "status": "completed", "content": [
                                        {"type": "output_text", "text": raw, "annotations": []}]}]}
            else:
                data = {"id": "msg_test", "type": "message", "role": "assistant",
                        "model": "claude-haiku-4-5-20251001", "content": [{"type": "text", "text": raw}],
                        "stop_reason": "max_tokens" if incomplete else "end_turn", "stop_sequence": None,
                        "usage": {"input_tokens": 10, "output_tokens": 10}}
            return httpx.Response(200, json=data)

        with patch.dict(os.environ, {"OPENAI_API_KEY": "unit-test", "ANTHROPIC_API_KEY": "unit-test"}):
            keeper = AIShopkeeper(provider)
        keeper.client.close()
        client_type = OpenAI if provider == "openai" else Anthropic
        with httpx.Client(transport=httpx.MockTransport(handle)) as http:
            with client_type(api_key="unit-test", http_client=http, max_retries=0) as client:
                keeper.client = client
                result = keeper.request("a golf ball", shop if shop is not None else Shop())
        return result, expected, captured

    def test_real_openai_sdk_serializes_strict_schema(self):
        result, expected, requests = self.request_with_response("openai")
        self.assertEqual(result, expected)
        self.assertEqual(requests[0]["text"]["format"]["schema"], SHOP_SCHEMA)
        self.assertTrue(requests[0]["text"]["format"]["strict"])
        self.assertFalse(requests[0]["store"])
        self.assertIn("Calibration columns:", requests[0]["instructions"])
        shop = Shop()
        shop.apply(result)
        self.assertEqual(shop.cart[0].name, "Golf Ball")

    def test_real_anthropic_sdk_serializes_schema(self):
        result, expected, requests = self.request_with_response("anthropic")
        self.assertEqual(result, expected)
        self.assertEqual(requests[0]["output_config"]["format"]["schema"], SHOP_SCHEMA)
        self.assertEqual(requests[0]["system"], SHOP_PROMPT)
        self.assertEqual(requests[0]["messages"][-1]["role"], "user")

    def test_only_item_references_are_sent_with_the_request(self):
        shop = Shop()
        shop.apply(quote(add("Golf Club")))
        shop.checkout()
        shop.inventory[0].damage(30)
        shop.selling.append("01")
        shop.apply(quote(add("Raw Egg")))
        for provider in ("openai", "anthropic"):
            with self.subTest(provider=provider):
                _, _, requests = self.request_with_response(provider, shop=shop)
                messages = requests[0]["input" if provider == "openai" else "messages"]
                self.assertEqual(len(messages), 1)
                self.assertEqual(json.loads(messages[0]["content"]), {
                    "request": "a golf ball",
                    "cart": [{"id": "1", "name": "Raw Egg"}],
                    "owned": [{"id": "1", "name": "Golf Club"}],
                    "selling_ids": ["1"],
                })

    def test_ai_line_numbers_translate_back_to_internal_ids(self):
        shop = Shop()
        shop.apply(quote(add("Golf Ball"), add("Raw Egg")))
        shop.apply(quote({"kind": "remove", "item_id": "01", "item": None}))
        response = quote({"kind": "remove", "item_id": "1", "item": None})
        self.assertEqual(shop.cart[0].id, "02")
        self.assertEqual(internalize_line_numbers(response, shop)["actions"][0]["item_id"], "02")

    def test_incomplete_and_unreadable_quotes_leave_shop_unchanged(self):
        for provider in ("openai", "anthropic"):
            for arguments in ({"incomplete": True}, {"payload": "not json"}):
                with self.subTest(provider=provider, arguments=arguments), self.assertRaises(ShopError):
                    self.request_with_response(provider, **arguments)

    def test_api_errors_are_actionable_and_do_not_echo_secrets(self):
        for provider in ("openai", "anthropic"):
            for status, expected in ((401, "API key rejected"), (429, "API limit reached"),
                                     (404, "model access"), (500, "connection")):
                with self.subTest(provider=provider, status=status):
                    with self.assertRaises(ShopError) as raised:
                        self.request_with_response(provider, status=status)
                    self.assertIn(expected, str(raised.exception))
                    self.assertNotIn("secret-value", str(raised.exception))

    def test_sound_effect_uses_a_tiny_plain_text_request(self):
        prompt = "What sound does Pool Noodle hitting Golf Ball make: give only a short, object-specific onomatopoeia without quotes or Markdown."
        for provider in ("openai", "anthropic"):
            with self.subTest(provider=provider):
                keeper = object.__new__(AIShopkeeper)
                keeper.provider = provider
                keeper.model = "test-model"
                keeper.client = Mock()
                keeper.client.with_options.return_value = keeper.client
                if provider == "openai":
                    keeper.client.responses.create.return_value = SimpleNamespace(output_text='*fwump!*')
                else:
                    block = SimpleNamespace(type="text", text='"fwump!"')
                    keeper.client.messages.create.return_value = SimpleNamespace(content=[block])
                self.assertEqual(keeper.sound_effect("Pool Noodle", "Golf Ball"), "fwump!")
                self.assertTrue(keeper.last_sound_generated)
                keeper.client.with_options.assert_called_once_with(timeout=5.0, max_retries=0)
                call = (keeper.client.responses.create if provider == "openai"
                        else keeper.client.messages.create).call_args.kwargs
                self.assertEqual(call.get("input", call.get("messages", [{}])[0].get("content")), prompt)
                self.assertEqual(call.get("max_output_tokens", call.get("max_tokens")), 20)

    def test_sound_effect_failure_does_not_interrupt_play(self):
        keeper = object.__new__(AIShopkeeper)
        keeper.provider = "openai"
        keeper.model = "test-model"
        keeper.client = Mock()
        keeper.client.with_options.return_value = keeper.client
        keeper.client.responses.create.side_effect = RuntimeError
        keeper.last_sound_generated = True
        self.assertEqual(keeper.sound_effect("Club", "Ball"), "Thwack!")
        self.assertFalse(keeper.last_sound_generated)


class PromptTests(unittest.TestCase):
    def test_compact_examples_preserve_physics_and_standard_equipment(self):
        from ai_shop import EXAMPLES, EXAMPLE_FIELDS
        from demo import load_catalog
        from items import Item
        catalog = {entry["name"]: entry for entry in load_catalog()}
        names = set()
        for index, row in enumerate(EXAMPLES.splitlines()):
            values = row.split("|")
            self.assertEqual(len(values), len(EXAMPLE_FIELDS))
            data = dict(zip(EXAMPLE_FIELDS, [values[0], *map(float, values[1:])]))
            original = catalog[data["name"]]
            for field, value in data.items():
                self.assertEqual(value, original[field])
            data.update(description=original["description"], material=original["material"])
            names.add(Item.from_generated(data, str(index)).name)
        self.assertTrue({"Golf Ball", "Golf Club", "7-Iron", "Putter", "Sand Wedge",
                         "Raw Egg", "Lightbulb", "Diamond", "The Sun"} <= names)

    def test_open_ended_properties_accept_the_infinity_sentinel(self):
        item_schema = SHOP_SCHEMA["properties"]["actions"]["items"]["properties"]["item"]
        properties = item_schema["anyOf"][0]["properties"]
        for name in ("mass_kg", "length_m", "area_m2", "durability_j"):
            self.assertEqual(properties[name]["anyOf"][1]["enum"], ["Infinity"])
        self.assertEqual(properties["rolling_resistance"]["type"], "number")


if __name__ == "__main__":
    unittest.main()
