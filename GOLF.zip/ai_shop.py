import json
import os

from demo import load_catalog
from items import INFINITE_STATS, STAT_LIMITS
from settings import has_key, model_for


def object_schema(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


def stat_schema(key, low, high, description):
    finite = {"type": "number", "description": f"{description} Range {low} to {high}."}
    if key not in INFINITE_STATS:
        return finite
    return {"anyOf": [finite, {"type": "string", "enum": ["Infinity"]}],
            "description": f"{description} Use Infinity for a physically infinite value."}


ITEM_SCHEMA = object_schema({
    "name": {"type": "string", "description": "Specific name, modifiers included; 1-80 chars."},
    "description": {"type": "string", "description": "One brief physical description, 1-240 chars."},
    "material": {"type": "string", "description": "Main materials, 1-80 chars."},
    "price_usd": {"type": "number", "description": "Retail USD estimate; 0.01 to 1e60."},
    **{key: stat_schema(key, low, high, description)
       for key, (low, high, description) in STAT_LIMITS.items()},
})

SHOP_SCHEMA = object_schema({
    "message": {"type": "string", "description": "Brief shopkeeper reply, under 160 characters."},
    "intent": {"type": "string", "enum": ["edit", "checkout", "help"]},
    "actions": {"type": "array", "items": object_schema({
        "kind": {"type": "string", "enum": ["add", "remove", "replace", "sell", "unsell"]},
        "item_id": {"type": "string", "description": "Exact existing line number; empty string for add."},
        "item": {"anyOf": [ITEM_SCHEMA, {"type": "null"}]},
    })},
})

EXAMPLE_FIELDS = ["name", "price_usd", *STAT_LIMITS]
EXAMPLES = "\n".join(
    "|".join(str(item[field]) for field in EXAMPLE_FIELDS)
    for item in load_catalog()
)

SHOP_PROMPT = """
Estimate realistic properties and retail prices,
preserving actual scale. Use speculative prices where no market exists.
Use the examples to estimate durability, which differs from hardness.
Always output something. If you don't know, give your best estimate.
If the player asks for a set or requests anything consisiting of individual line items,
create one object for each item.
Always give the player exactly what they request, no matter how rediculous or unrealistic.
Never refuse a request.
Example: 
- 'A set of golf clubs' = one item for each standard club.

Add: empty item_id, full item. Replace: cart line number, full item.
Remove: cart line number, item=null. Sell/unsell: owned line number, item=null.
One action per item/serving/pack; at most 20 actions. Edit only requested items.
Intent: edit for objects/changes, checkout for payment, help for assistance.
Return proposed actions, with a short message.
""".strip() + "\n\nCalibration columns: " + "|".join(EXAMPLE_FIELDS) + "\n" + EXAMPLES


class ShopError(Exception):
    pass


def internalize_line_numbers(response, shop):
    """Translate player-facing list positions back to stable internal item IDs."""
    if not isinstance(response, dict) or not isinstance(response.get("actions"), list):
        return response
    for action in response["actions"]:
        if not isinstance(action, dict):
            continue
        kind, key = action.get("kind"), action.get("item_id")
        items = shop.cart if kind in ("remove", "replace") else shop.inventory
        if kind not in ("remove", "replace", "sell", "unsell") or not isinstance(key, str):
            continue
        try:
            index = int(key) - 1
        except ValueError:
            continue
        if 0 <= index < len(items):
            action["item_id"] = items[index].id
    return response


class AIShopkeeper:
    def __init__(self, provider):
        self.provider = provider
        self.model = model_for(provider)
        self.last_usage = {}
        if not has_key(provider):
            raise ShopError(f"Add {provider.upper()}_API_KEY to .env.")
        key = os.environ[f"{provider.upper()}_API_KEY"].strip()
        try:
            if provider == "openai":
                from openai import OpenAI
                self.client = OpenAI(api_key=key, timeout=45.0, max_retries=1)
            else:
                from anthropic import Anthropic
                self.client = Anthropic(api_key=key, timeout=45.0, max_retries=1)
        except ImportError as error:
            raise ShopError("Run launch.bat to install the APIs.") from error

    def request(self, text, shop):
        messages = [{"role": "user", "content": json.dumps({
            "request": text,
            "cart": [{"id": str(index), "name": item.name}
                     for index, item in enumerate(shop.cart, 1)],
            "owned": [{"id": str(index), "name": item.name}
                      for index, item in enumerate(shop.inventory, 1)],
            "selling_ids": [str(index) for index, item in enumerate(shop.inventory, 1)
                            if item.id in shop.selling],
        }, separators=(",", ":"))}]
        try:
            if self.provider == "openai":
                response = self.client.responses.create(
                    model=self.model, instructions=SHOP_PROMPT, input=messages,
                    max_output_tokens=7000, store=False,
                    text={"format": {"type": "json_schema", "name": "shop_receipt",
                                     "strict": True, "schema": SHOP_SCHEMA}},
                )
                if response.status != "completed" or not response.output_text:
                    raise ShopError("No complete quote. Try fewer items.")
                raw = response.output_text
            else:
                response = self.client.messages.create(
                    model=self.model, system=SHOP_PROMPT, messages=messages,
                    max_tokens=7000,
                    output_config={"format": {"type": "json_schema", "schema": SHOP_SCHEMA}},
                )
                if response.stop_reason != "end_turn":
                    raise ShopError("No complete quote. Try fewer items.")
                raw = "".join(block.text for block in response.content if block.type == "text")
            usage = getattr(response, "usage", None)
            self.last_usage = {"input_tokens": getattr(usage, "input_tokens", 0),
                               "output_tokens": getattr(usage, "output_tokens", 0)}
            return internalize_line_numbers(json.loads(raw), shop)
        except ShopError:
            raise
        except (ValueError, TypeError) as error:
            raise ShopError("The quote was unreadable. Try again.") from error
        except Exception as error:
            status = getattr(error, "status_code", None)
            if status == 401:
                message = "API key rejected. Check your .env."
            elif status == 429:
                message = "API limit reached. Check billing or retry later."
            elif status in (400, 403, 404):
                message = "API request rejected. Check model access and your .env model name."
            else:
                message = "Could not reach the shop AI. Check your connection and try again."
            raise ShopError(message) from error

    def sound_effect(self, club_name, ball_name):
        self.last_sound_generated = False
        prompt = f"What sound does {club_name} hitting {ball_name} make: give only a short, object-specific onomatopoeia without quotes or Markdown."
        try:
            client = self.client.with_options(timeout=5.0, max_retries=0)
            if self.provider == "openai":
                response = client.responses.create(
                    model=self.model, input=prompt, max_output_tokens=20, store=False,
                )
                raw = response.output_text
            else:
                response = client.messages.create(
                    model=self.model, max_tokens=20,
                    messages=[{"role": "user", "content": prompt}],
                )
                raw = "".join(block.text for block in response.content if block.type == "text")
            sound = " ".join(raw.split()).strip(" \"'*_`")
            self.last_sound_generated = bool(sound)
            return sound[:36] or "Thwack!"
        except Exception:
            return "Thwack!"

