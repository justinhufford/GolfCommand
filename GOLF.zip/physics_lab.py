import argparse
from dataclasses import asdict
import json
from pathlib import Path

from demo import load_catalog
from items import Item
from physics import METERS_PER_YARD, calculate_shot
from terminal import Terminal


PAIRS = [
    ("Golf Ball", "Golf Club"),
    ("Golf Ball", "7-Iron"),
    ("Golf Ball", "Putter"),
    ("Golf Ball", "Sand Wedge"),
    ("Golf Ball", "Pool Noodle"),
    ("Pool Noodle", "Golf Club"),
    ("Party Balloon", "Golf Club"),
    ("Raw Egg", "Sledgehammer"),
    ("Lightbulb", "Sledgehammer"),
    ("Diamond", "Sledgehammer"),
    ("Bowling Ball", "Golf Club"),
    ("Feather", "Golf Club"),
    ("Golf Ball", "Raw Egg"),
    ("Golf Club", "Golf Ball"),
    ("The Sun", "Golf Club"),
    ("Golf Ball", "The Sun"),
]


def main():
    parser = argparse.ArgumentParser(description="Compare shared item physics without an API key.")
    parser.add_argument("--json", type=Path, help="Also write numerical results to this file.")
    args = parser.parse_args()
    catalog = {data["name"]: Item.from_generated(data, str(index))
               for index, data in enumerate(load_catalog())}
    ui = Terminal(fast=True)
    results = []
    try:
        ui.title("Physics lab / sample estimates")
        ui.write("B = ball HP lost; C = club HP lost")
        for ball_name, club_name in PAIRS:
            ball, club = catalog[ball_name], catalog[club_name]
            ui.rule()
            ui.write(f"{club_name} -> {ball_name}")
            ui.write("PWR      YARDS     B HP     C HP")
            for power in (0.1, 0.5, 1.0):
                shot = calculate_shot(ball, club, power)
                yards = shot.distance_m / METERS_PER_YARD
                ui.write(f"{power:3.0%} {yards:10.2f} {shot.ball_damage:8.2f} {shot.club_damage:8.2f}")
                results.append({"ball": ball_name, "club": club_name, "power": power, **asdict(shot)})
        if args.json:
            args.json.write_text(json.dumps(results, indent=2), encoding="utf-8")
    finally:
        ui.close()


if __name__ == "__main__":
    main()
