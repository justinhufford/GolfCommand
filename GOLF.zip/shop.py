from dataclasses import dataclass, field, replace

from items import Item


STARTING_CENTS = 50_000
MAX_ITEMS = 40
MAX_ACTIONS = 20


@dataclass
class Shop:
    wallet: int = STARTING_CENTS
    infinite_money: bool = False
    inventory: list = field(default_factory=list)
    cart: list = field(default_factory=list)
    selling: list = field(default_factory=list)
    catalog: dict = field(default_factory=dict)
    ai_catalog: set = field(default_factory=set)
    next_id: int = 1

    @property
    def purchase_total(self):
        return sum(item.price_cents for item in self.cart)

    @property
    def sale_total(self):
        return sum(item.resale_cents for item in self.inventory if item.id in self.selling)

    @property
    def total(self):
        return self.purchase_total - self.sale_total

    def apply(self, response, *, ai_generated=False):
        if not isinstance(response, dict) or set(response) != {"message", "actions", "intent"}:
            raise ValueError("Invalid shop response.")
        if not isinstance(response["message"], str) or len(response["message"]) > 500:
            raise ValueError("Invalid shop message.")
        if response["intent"] not in ("edit", "checkout", "play", "help"):
            raise ValueError("Unknown shop intent.")
        actions = response["actions"]
        if not isinstance(actions, list) or len(actions) > MAX_ACTIONS:
            raise ValueError("Too many receipt changes.")
        draft = replace(self, cart=self.cart.copy(), selling=self.selling.copy(),
                        catalog=self.catalog.copy(), ai_catalog=self.ai_catalog.copy())
        for action in actions:
            draft.apply_action(action, ai_generated=ai_generated)
        if len(draft.cart) + len(self.inventory) - len(draft.selling) > MAX_ITEMS:
            raise ValueError(f"Carry up to {MAX_ITEMS} items.")
        self.cart, self.selling = draft.cart, draft.selling
        self.catalog, self.next_id = draft.catalog, draft.next_id
        self.ai_catalog = draft.ai_catalog

    def apply_action(self, action, *, ai_generated=False):
        if not isinstance(action, dict) or set(action) != {"kind", "item_id", "item"}:
            raise ValueError("Invalid receipt change.")
        kind, item_id, data = action["kind"], action["item_id"], action["item"]
        if not isinstance(item_id, str):
            raise ValueError("Invalid item number.")
        if kind in ("add", "replace"):
            if kind == "add" and item_id != "":
                raise ValueError("New items cannot set IDs.")
            generated = Item.from_generated(data, f"{self.next_id:02d}", ai_generated=ai_generated)
            key = generated.name.casefold()
            if key in self.catalog:
                generated = Item.from_generated(self.catalog[key], generated.id,
                                                ai_generated=key in self.ai_catalog)
            else:
                self.catalog[key] = data.copy()
                if ai_generated:
                    self.ai_catalog.add(key)
            if kind == "replace":
                old = self.find(self.cart, item_id)
                self.cart[self.cart.index(old)] = generated
            else:
                self.cart.append(generated)
            self.next_id += 1
        elif kind in ("remove", "sell", "unsell"):
            if data is not None:
                raise ValueError("Existing items keep their stats.")
            if kind == "remove":
                self.cart.remove(self.find(self.cart, item_id))
            elif kind == "sell":
                self.find(self.inventory, item_id)
                if item_id in self.selling:
                    raise ValueError("Already on the sale receipt.")
                self.selling.append(item_id)
            else:
                if item_id not in self.selling:
                    raise ValueError("That item is not for sale.")
                self.selling.remove(item_id)
        else:
            raise ValueError("Unknown receipt change.")

    @staticmethod
    def find(items, item_id):
        for item in items:
            if item.id == item_id:
                return item
        raise ValueError("That item number was not found.")

    def checkout(self):
        if not self.cart and not self.selling:
            raise ValueError("Your receipt is empty.")
        if not self.infinite_money and self.total > self.wallet:
            raise ValueError("Not enough money. Edit the receipt.")
        if not self.infinite_money:
            self.wallet -= self.total
        self.inventory = [item for item in self.inventory if item.id not in self.selling]
        self.inventory.extend(self.cart)
        self.clear()

    def clear(self):
        self.cart = []
        self.selling = []
