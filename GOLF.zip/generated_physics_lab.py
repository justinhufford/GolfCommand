"""Generate one varied item batch, then test every pairing locally."""

import argparse
from dataclasses import asdict
import json
import math
from pathlib import Path

from ai_shop import AIShopkeeper, ShopError
from physics import METERS_PER_YARD, calculate_shot
from settings import load_env
from shop import Shop


ITEM_REQUEST = """One each in this exact order: regulation golf ball; standard
driver; pool noodle; empty cardboard paper-towel tube; steel pipe one meter long;
raw chicken egg; incandescent lightbulb; tennis ball; bowling ball; goose feather;
wet bath towel; floppy squeaky rubber chicken toy; cast-iron skillet; glass marble; cinder block;
inflated helium party balloon; wooden baseball bat; frozen hot dog."""


def yards(ball, club, power=1):
    return calculate_shot(ball, club, power).distance_m / METERS_PER_YARD


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=["openai", "anthropic"], required=True)
    parser.add_argument("--output", type=Path, default=Path("generated-physics-results.json"))
    args = parser.parse_args()
    load_env()
    report = {"provider": args.provider, "request": ITEM_REQUEST, "checks": [], "shots": []}

    def check(name, passed, details):
        report["checks"].append({"name": name, "passed": bool(passed), "details": details})
        print(("PASS" if passed else "FAIL") + f"  {name}: {details}")

    try:
        keeper = AIShopkeeper(args.provider)
        report["model"] = keeper.model
        shop = Shop(infinite_money=True)
        response = keeper.request(ITEM_REQUEST, shop)
        shop.apply(response)
        items = shop.cart
        report["usage"] = keeper.last_usage
        report["items"] = [item.details() for item in items]
        print(f"Generated {len(items)} items with {keeper.model}.")
        print("Token usage:", keeper.last_usage)
        check("item count", len(items) == 18, str(len(items)))
        if len(items) != 18:
            return 1

        ball, driver, noodle, tube, pipe, egg, bulb, tennis, bowling = items[:9]
        feather, towel, chicken, skillet, marble, block, balloon, bat, hotdog = items[9:]
        expected = ("golf", "driver", "noodle", "tube", "pipe", "egg", "bulb",
                    "tennis", "bowling", "feather", "towel", "chicken", "skillet",
                    "marble", "block", "balloon", "bat", "hot dog")
        order_ok = all(word in item.name.lower() for word, item in zip(expected, items))
        check("identity and order", order_ok, ", ".join(item.name for item in items))

        for target in items:
            for club in items:
                if target.id == club.id:
                    continue
                for power in (0.01, 0.1, 0.5, 0.97, 1):
                    shot = calculate_shot(target, club, power)
                    values = (shot.distance_m, shot.club_speed, shot.ball_speed,
                              shot.ball_damage, shot.club_damage)
                    if not all(math.isfinite(value) and value >= 0 for value in values):
                        raise ValueError(f"Non-finite result: {club.name} -> {target.name}")
                    report["shots"].append({"ball": target.name, "club": club.name,
                                            "power": power, **asdict(shot)})
        check("all pairings finite", True, f"{len(report['shots'])} shots")

        driver_yards = yards(ball, driver)
        noodle_yards = yards(ball, noodle, 0.97)
        towel_yards = yards(ball, towel)
        tube_yards = yards(ball, tube)
        bowling_yards = yards(bowling, driver)
        check("standard drive", 150 <= driver_yards <= 450, f"{driver_yards:.2f} yd")
        check("pool noodle", noodle_yards < 15, f"{noodle_yards:.2f} yd; rigidity {noodle.rigidity:g}")
        check("wet towel", towel_yards < 15, f"{towel_yards:.2f} yd; rigidity {towel.rigidity:g}")
        check("cardboard tube", tube_yards < driver_yards * 0.35, f"{tube_yards:.2f} yd")
        check("bowling ball", bowling_yards < 20, f"{bowling_yards:.2f} yd")
        check("egg breaks", calculate_shot(egg, pipe, 1).ball_broken, "steel pipe at full power")
        check("bulb breaks", calculate_shot(bulb, bat, 1).ball_broken, "baseball bat at full power")
        check("balloon breaks", calculate_shot(balloon, driver, 0.5).ball_broken, "driver at 50%")
        check("heavy target moves less", yards(block, driver) < driver_yards * 0.1,
              f"block {yards(block, driver):.2f} yd")
        check("flexible objects rated low", max(noodle.rigidity, towel.rigidity, balloon.rigidity) <= 0.25,
              f"{noodle.rigidity:g}, {towel.rigidity:g}, {balloon.rigidity:g}")
        return 0 if all(entry["passed"] for entry in report["checks"]) else 1
    except (ShopError, ValueError) as error:
        report["error"] = str(error)
        print("ERROR", error)
        return 1
    finally:
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("Saved", args.output)


if __name__ == "__main__":
    raise SystemExit(main())
