# GOLF

A small terminal golf game where anything can be equipment. Start with $500 in the Pro Shop, ask for objects, edit the receipt, and buy them. Pick any two different items as your ball and club. Finish a hole to earn money, then return to buy and sell.

## Run it

Install Python 3.10 or newer, then double-click **launch.bat**. It creates `.venv`, installs the OpenAI and Anthropic clients, creates `.env` if missing, and starts the game. Later launches reuse that setup. If installation fails, see `.venv/setup.log`.

Put one API key in `.env` beside `GOLF.py`:

```dotenv
GOLF_PROVIDER=openai
OPENAI_API_KEY=your-actual-key
```

Or:

```dotenv
GOLF_PROVIDER=anthropic
ANTHROPIC_API_KEY=your-actual-key
```

Leave `GOLF_PROVIDER` blank to choose at startup. Defaults are `gpt-4.1-mini` and `claude-haiku-4-5-20251001`; override `OPENAI_MODEL` or `ANTHROPIC_MODEL` in `.env` to try another model with structured output support. Restart after editing `.env`. Existing environment variables take precedence. Keys are never printed, included in prompts, or committed by the supplied `.gitignore`.

To play without a key or install:

```powershell
python GOLF.py --demo
```

Or use `launch.bat --demo` to set up the environment without installing the API clients. Demo mode has a fixed catalog. Type `starter` for a golf ball and driver, `lunch` for the burger/drink/fries sample, or an individual catalog name. Freeform language interpretation requires a live provider; the demo does not pretend to interpret the lunch stress test.

Useful options:

```powershell
python GOLF.py --demo --fast --manual-power --seed 1
```

`--fast` removes printing delays. `--manual-power` lets you type a number instead of timing the meter. A seed repeats the sequence of holes. Redirected input automatically uses numerical power. Normal Windows Terminal and Command Prompt support the animated meter. The receipt has 36 columns of content and a two-space left margin (38 columns overall). Long typed requests scroll horizontally. `NO_COLOR` disables color.

White is the game's own ink: headings, controls, item numbers, totals, condition, resale, and shot results. Green (ANSI 256-color 42) marks AI-written dialogue, sounds, item names, descriptions, quoted prices, and generated properties. Your typed input is green too. Offline catalog items and fallback sound effects stay white. Items remember their origin, including when you switch shopkeepers or reuse a cached quote.

Printing keeps a receipt-printer rhythm: item rows feed quickly, longer prose takes a little more time, and section breaks, sound effects, and score reveals get a pause. The original small logo and a single rule per heading keep the paper uncluttered; terminals without Unicode get a readable text logo.

## Play

The shopkeeper accepts requests such as:

```text
an egg and a sledgehammer
remove the egg
make the hammer smaller
sell my old driver
```

Bare names such as `pool noodle` request the ordinary object; unspecified details use ordinary defaults. You choose its ball or club role on the course.

The AI instructions describe general objects and physical properties, with no golf-game framing or equipment roles. Shop edits and checkout remain available to the AI; `play` is handled locally by the game. Golf equipment appears only as ordinary calibration items or requested products.

The opening screen shows your wallet, the shopkeeper's question, and a short path to your first round. Receipts show item prices, the total due (or what the shop pays you), and your balance after checkout. If you're over budget, the receipt shows how much to trim. Long item names wrap with an indented continuation and aligned prices. Use `help` for commands and `inspect` for labeled properties and units.

Purchases and trade-ins stay on a pending receipt until `checkout`. You can also use these local commands without an API call:

| Command | Effect |
| --- | --- |
| `receipt` | Show pending purchases, sales, and totals. |
| `inspect 1` | Show every stat of a visible item. |
| `bag` | Show owned items, condition, and resale values. |
| `remove 1` | Remove a pending purchase by receipt line. |
| `sell 1` | Add an item to the receipt by its bag line. |
| `keep 1` | Cancel a trade-in by its receipt line. |
| `clear` | Clear all pending purchases and sales. |
| `checkout` | Pay the net total and transfer ownership. |
| `play` | Choose equipment and start a hole. |
| `provider` | Choose another provider or the demo catalog. |
| `help` / `quit` | Show commands / exit. |

Visible item numbers are always current list positions without leading zeroes. Receipt, bag, and equipment lists each run from `1` to the number of rows shown, and close gaps immediately when an item is removed. Choose equipment by item number or a unique part of its name. Enter keeps your current selection, or selects the only available item; `cancel` returns to the shop during setup, or to the current hole when swapping equipment. The ball is the object you hit, and the club is the object you swing.

The course is a compact line: `●` marks the ball and `○` the hole. Each swing aims toward the hole, including after an overshoot. The next shot number and a full-power distance estimate appear before every swing. Press Enter at `> ` to start the meter, then Enter again to choose power. Its tightly packed `▌` cells fill all 36 receipt columns, rising from 0% to 100% and falling back to 0% on a slightly faster three-second cycle. The locked bar stays on the receipt, and the exact percentage prints with the shot result. The minimap and meter each get a blank paper-feed line above and below. Escape cancels a swing without using a stroke. `ball` and `club` let you swap equipment between swings.

On the course, `help` shows controls, `look` shows your equipment and full-power estimate, and `inspect #` shows item stats. Each hit prints a short sound effect before its power and distance; significant damage and broken equipment are called out as they happen.

Stop within 0.6 meters (about 0.66 yards) to finish. This is a generous target for a timing toy. A zero-power swing still costs a stroke. Broken balls make no progress; replace them at the current position if you have a spare. Any object size can count as holed out.

One hole is one round. Holes are 120–420 yards, with par 3–5. A hole in one pays $300. Other completed holes pay $100 minus $25 per stroke over par, or plus $25 per stroke under par, with a $25 minimum. Leaving early or reaching 12 strokes pays nothing. Back in the shop, used equipment sells for 60% of its original price multiplied by remaining condition; broken items have no resale value.

This first version keeps everything in memory. Relaunching starts a fresh $500 game.

## Tinker with it

There are no frameworks, database, or game-engine dependencies. The two API SDKs install their own dependencies; the game otherwise uses Python's standard library.

| File | What to change |
| --- | --- |
| `GOLF.py` | Game flow, commands, receipts, and course display. |
| `items.py` | The shared item dataclass, valid stat ranges, and resale rule. |
| `physics.py` | Swing equations, wear, hole tolerance, and prize amounts. |
| `shop.py` | Starting money, cart edits, checkout, and inventory limits. |
| `ai_shop.py` | Provider calls, JSON schema, and shopkeeper instructions. |
| `demo_items.json` | Example objects; their numerical stats become compact prompt rows. |
| `terminal.py` | Line width, printing delays, colors, keyboard input, and meter speed. |
| `settings.py` | Small `.env` reader and default models. |
| `bootstrap.py` / `launch.bat` | One-click setup. |

Start by changing an example item, then run `python physics_lab.py`. For example, lower the egg's `durability_j`, increase a ball's `rolling_resistance`, or try a different `SWING_ENERGY_J` in `physics.py`.

## Teaching smaller models

Every generated object uses the same fields. There is no ball/club classification, item whitelist, or separate generation call for each role. The schema requests a name, description, material, price, and these numerical properties:

| Field | Meaning |
| --- | --- |
| `mass_kg` | Actual mass, including astronomical values. |
| `length_m` | Longest dimension; contributes to usable reach. |
| `area_m2` | Projected area for air drag. |
| `loft_degrees` | Usual face tilt when striking; applied automatically. |
| `grip` | How well a person can hold it, from 0 to 1. |
| `rigidity` | How effectively it transmits a hit, from 0 to 1. |
| `restitution` | Bounciness, from 0 to 1. |
| `drag_coefficient` | Shape-dependent air resistance. |
| `rolling_resistance` | Resistance to moving along grass. |
| `hardness` | Relative surface hardness; allocates damage between objects. |
| `durability_j` | A calibrated budget of absorbed impact energy before destruction. |

The prompt uses short shop rules and 25 compact calibration rows spanning standard equipment, flexible and fragile objects, tiny rigid objects, awkward tools, heavy objects, food, and astronomical scale. One shared header labels each row's name, price, and numerical stats; repeated JSON keys, descriptions, and material labels are omitted. Field definitions stay brief so the examples teach the scale. Durability is an effective game budget, separate from hardness: diamond can be hard and brittle at the same time. Subatomic masses and pointlike zero dimensions are valid. Mass, length, area, and durability also accept `Infinity`; zero rolling resistance naturally produces infinite travel. Undefined combinations are allowed to print `NaN yd`.

`demo_items.json` is also the calibration dataset. Changing it changes both the offline examples and the teaching prompt on the next launch. That makes model prompting and physics tuning easier to keep in sync. The examples are estimates; matching them does not establish scientific accuracy.

Each natural-language shop turn makes one structured-output request, potentially generating multiple items. The AI translates the latest input into objects or proposed item edits. It receives only that input, current line numbers and names for cart and owned items, and the line numbers pending sale so it can identify edit targets. No wallet, condition, existing prices, catalog stats, or conversation history is sent. The fixed calibration examples still teach physical properties. Each completed swing makes one separate plain-text request capped at 20 output tokens for its sound effect. Demo mode chooses a sound locally.

Python handles prices already quoted, affordability, condition, resale, and applying changes. Identically named products reuse their first quoted stats and price during the session. Invalid responses are rejected atomically without changing money or inventory. There is no extra AI repair pass, though the SDK may retry a failed HTTP request once.

Provider integration follows the [OpenAI structured outputs guide](https://developers.openai.com/api/docs/guides/structured-outputs) and [Anthropic structured outputs guide](https://platform.claude.com/docs/en/build-with-claude/structured-outputs). OpenAI uses Responses with a strict JSON schema; Anthropic uses Messages with `output_config.format`. Model support and account access can vary.

## The physics model

This is a deterministic, one-dimensional toy. It uses a bounded human swing, a collision calculation, and an effective stopping distance. It does not simulate flight, spin, terrain, deformation geometry, heat, gravity from the objects themselves, or nuclear reactions. The Sun retains its enormous stats and price, but cannot be swung; purchasing it does not destroy the course.

1. **Swing energy.** The player's energy budget is 280 J at full power, reduced by grip, usable reach, wear, and the difficulty of lifting a heavy object. Power scales speed approximately linearly because energy scales with `power ** 2`. A tiny object is limited to roughly 10 m/s hand speed; longer objects progressively gain leverage up to the 55 m/s cap. Astronomical masses are retained rather than squeezed into a handheld range.
2. **Momentum transfer.** The starting point is `ball_speed = (1 + bounce) * club_mass / (club_mass + ball_mass) * club_speed`. Rigidity and condition reduce transfer. Face loft reduces forward speed by `cos(loft) ** 2`. Loft affects the automatic calculation; the player never chooses an angle. This reduction is a simplified contact approximation and does not calculate airborne carry.
3. **Damage.** Lost impact energy, plus a small fatigue allowance, is divided between the objects using relative hardness. `HP lost = 100 * absorbed_energy / durability_j`. A small brittle shell can exhaust its budget in one hit. A broken club transmits only a reduced hit; a shattered ball travels zero. Remaining condition reduces later performance.
4. **Stopping distance.** Effective grass resistance is `friction = rolling_resistance * g`, and `drag = 0.5 * air_density * drag_coefficient * area / mass`. Integrating deceleration `friction + drag * speed ** 2` gives `distance = log(1 + drag * speed ** 2 / friction) / (2 * drag)`. With zero drag, this becomes `speed ** 2 / (2 * friction)`. The quadratic drag term uses the [NASA drag equation](https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/drag-equation/).

These simplifications keep the code small and the outcomes legible. A full-power putter uses the same human swing budget as any other object; it is not restricted to a putting stroke. Normal short putts use roughly 1–10% power.

Sample calibration results with fresh equipment:

| Club → ball | Power | Distance | Outcome |
| --- | ---: | ---: | --- |
| Driver → golf ball | 100% | 295.3 yd | Both remain usable. |
| 7-iron → golf ball | 100% | 183.5 yd | Shorter forward shot. |
| Sand wedge → golf ball | 100% | 60.1 yd | Shorter again. |
| Putter → golf ball | 10% | 6.8 yd | Fine control at lower power. |
| Pool noodle → golf ball | 100% | 0.7 yd | Flexible club transfers little energy. |
| Sledgehammer → egg | 100% | 0 yd | Egg breaks. |
| Sledgehammer → lightbulb | 100% | 0 yd | Bulb breaks. |
| Driver → party balloon | 50% | 0 yd | Balloon pops. |
| Sledgehammer → diamond | 100% | 19.9 yd | Diamond loses about 2.6 HP. |
| Driver → bowling ball | 100% | 1.9 yd | Much harder to move. |

## Tests

After setup:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -v
python physics_lab.py
```

The unit suite needs no API key. It covers standard equipment, fragile objects, wear, resale, cart edits, cash limits, solar-scale numbers, power timing, line widths, and a complete scripted purchase → hole → prize → sale loop. It also exercises all 625 example ball/club pairings at five powers and 300 generated combinations of extreme valid stats. API adapter tests use the installed SDKs with mocked HTTP responses. Without the SDKs, those tests are skipped.

To save the lab's numerical results:

```powershell
python physics_lab.py --json physics-results.json
```

Once a key is configured, run the opt-in live checks:

```powershell
.\.venv\Scripts\python.exe test_api.py --provider openai
.\.venv\Scripts\python.exe test_api.py --provider anthropic
```

Each invocation makes up to four paid API requests: the exact lunch request, conversational removal, a trade-in, and a ten-item equipment quote. It checks generated identities and broad physics baselines, prints shot distances, and saves raw generated responses, token usage, and outcomes in `api-test-results.json`. It stops on a failed check so a small model's mistakes are visible. Run again after changing a model or teaching examples to compare results. This is a smoke test, not proof that arbitrary generated objects will be physically accurate.
